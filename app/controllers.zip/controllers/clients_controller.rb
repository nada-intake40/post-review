class ClientsController < ApplicationController
  before_action :authenticate_user!

    def edit_promoter_profile
      promoter = Promoter.find(params[:promoter_id])
      promoter.name = params[:name]
      promoter.mobile = params[:mobile]
      if(params[:image] != "")

            photo = params[:image]
            img_split=photo.split(',')
            ext_split = img_split[0].split('/')
            ext  = ext_split[1].split(";")
            promoter_image = "user_img.#{ext[0]}"
            photoEncode = img_split[1]
            dir = File.dirname("public/promoters/#{promoter.id}/"+promoter_image)
            FileUtils.mkdir_p(dir) unless File.directory?(dir)
        
            decode_photo= Base64.decode64(photoEncode)
            File.open("public/promoters/#{promoter.id}/"+promoter_image, 'wb') { |f| f.write(decode_photo) }
            promoter.image = promoter_image

      end
      promoter.save
      render json: promoter
    end


    def list_distributed_samples
      project_id = current_user.project_id
      city_id = params[:city_id].blank? ? City.where(project_id: project_id).pluck(:id) : params[:city_id]
      retail_id = params[:retail_id].blank? ? RetailCompany.where(project_id: project_id).pluck(:id) : params[:retail_id]
      branch_id = params[:branch_id].blank? ? RetailCompanyBranch.joins(:retail_company)
      .where(retail_companies: {project_id: project_id}).pluck(:id) : params[:branch_id]
      start_date = params[:start_date].blank? ? (Date.today-7).beginning_of_day 
      : Date.parse(params[:start_date]).beginning_of_day
      end_date = params[:end_date].blank? ? Date.today.end_of_day 
      : Date.parse(params[:end_date]).end_of_day

      samples = Sample.joins(promoter_branch_day: [:promoter , retail_company_branch: [:city ,
       :retail_company , :store_class]]).where(cities:{id: city_id},retail_companies:
       {id: retail_id},retail_company_branches:{id: branch_id})
       .where('samples.created_at >= ? AND samples.created_at <= ?', start_date ,end_date)
      .select('DATE(samples.created_at) AS Date , cities.city_name AS 
       City , retail_companies.retail_company_name AS Chain , retail_company_branches.branch_name AS 
       Store , store_classes.class_name AS Class ,promoters.username AS "Promoter name" , total_samples
        AS Samples, distributed_samples AS "Distributed samples" , total_samples - distributed_samples AS
        "Remaining samples"')
       render json: samples , except: [:id]
    end

    def list_customer_engagements
      project_id = current_user.project_id
      city_id = params[:city_id].blank? ? City.where(project_id: project_id).pluck(:id) : params[:city_id]
      retail_id = params[:retail_id].blank? ? RetailCompany.where(project_id: project_id).pluck(:id) : params[:retail_id]
      branch_id = params[:branch_id].blank? ? RetailCompanyBranch.joins(:retail_company)
      .where(retail_companies: {project_id: project_id}).pluck(:id) : params[:branch_id]
      start_date = params[:start_date].blank? ? (Date.today-7).beginning_of_day 
      : Date.parse(params[:start_date]).beginning_of_day
      end_date = params[:end_date].blank? ? Date.today.end_of_day 
      : Date.parse(params[:end_date]).end_of_day
      
      customer_engagements = CustomerEngagement.joins(promoter_branch_day: [:promoter ,
       retail_company_branch: [:store_class,:city ,:retail_company ]])
      .where(cities:{id: city_id},retail_companies:{id: retail_id},retail_company_branches:
        {id: branch_id}).where('customer_engagements.created_at >= ? AND 
        customer_engagements.created_at <= ?', start_date ,end_date)
      .select('DATE(customer_engagements.created_at) AS Date ,cities.city_name
         AS City,retail_companies.retail_company_name AS Chain ,retail_company_branches.branch_name AS Store,
         store_classes.class_name AS Class ,promoters.username AS "Promoter name" ,customer_name AS "Customer name",
         email AS Email , phone AS "Phone #"')

      render json: customer_engagements,except: [:id]

    end


    def stock_count
      project_id = current_user.project_id
      city_id = params[:city_id].blank? ? City.where(project_id: project_id).pluck(:id) : params[:city_id]
      retail_id = params[:retail_id].blank? ? RetailCompany.where(project_id: project_id).pluck(:id) : params[:retail_id]
      branch_id = params[:branch_id].blank? ? RetailCompanyBranch.joins(:retail_company).where(retail_companies: {project_id: project_id}).pluck(:id) : params[:branch_id]
      start_date = params[:start_date].blank? ? (Date.today-7) : DateTime.parse(params[:start_date])
      end_date = params[:end_date].blank? ? Date.today : DateTime.parse(params[:end_date])
      is_expired = params[:is_expired] == 'n' ? 0 : 1
      stock = BranchStock.joins([device: {item: [:category,:brand ] },promoter_branch_day: [:promoter ,{retail_company_branch: [:retail_company , :city , :store_class]}]])
      .where(retail_companies: {project_id: project_id , id: retail_id} ,retail_company_branches: {city_id: city_id , id: branch_id},
        promoter_branch_days: {jcp_date: start_date ..end_date},
        is_expired: is_expired)
      .select('promoter_branch_days.jcp_date as Date ,cities.city_name as City , retail_companies.retail_company_name as Retail ,retail_company_branches.branch_name as Store, store_classes.class_name as Class
        , devices.device_name as Model ,items.item_name as Item , categories.category_name as Category, brands.brand_name as Brand,
        branch_stocks.quantity as Quantity , branch_stocks.item_price as "Shelfe Price", branch_stocks.expiration_date as "Near Expired" , promoters.username as "M.name" ')
      
        render json: stock ,except: [:id, :is_expired]
      
    end

    def get_reasons_percentage 
      all_jcp_implementations = JcpImplementation.where(promoter_branch_day_id: params[:jcp_id]).where.not(reason_id: nil)
      customer_restraction_percentage = get_percentage(all_jcp_implementations.where(reason_id:1).pluck(:implementation_percentage).sum,all_jcp_implementations.where(reason_id:1).count)
      out_of_stock_percentage = get_percentage(all_jcp_implementations.where(reason_id:2).pluck(:implementation_percentage).sum,all_jcp_implementations.where(reason_id: 2).count)
      share_of_shelfe_percantage = get_percentage(all_jcp_implementations.where(reason_id:3).pluck(:implementation_percentage).sum,all_jcp_implementations.where(reason_id: 3).count)
      render json: {'customer_restraction_percentage': customer_restraction_percentage , 'out_of_stock_percentage': out_of_stock_percentage , 'share_of_shelfe_percantage': share_of_shelfe_percantage}
    end

  	def view_jcp_detail
      jcp = PromoterBranchDay.where(id:params[:jcp_id])
  		render json: jcp ,include: [:power_of_wings_photos , retail_company_branch: {include: [:retail_company,:city,:store_class]} , jcp_implementations: {include: :category} ] , methods: [:get_duration_of_jcp]
  	end

  	def list_classes
  		classes = StoreClass.all
  		render json: classes
  	end

	def project_info
		project_id=current_user.project_id
		result={}
		result["total_promoter_count"]=Promoter.where(project_id: project_id).count
		result["total_sales"]= InvoiceDevice.joins(invoice: {retail_company_branch: :retail_company}).where("retail_companies.project_id = #{project_id}").sum("price*quantity")
		render json: result

	end

	def user_info
		project=Project.find(current_user.project_id)
		current_user.image_path=project.image_path
		render json: current_user, methods: [:image_path]
	end

	def profile
		project=ActiveSupport::JSON.decode(Project.find(current_user.project_id).to_json(:methods => [:formatted_end_date,:promoters_count,:days_left_percentage]))
		render json: {
			client:current_user,
			project:project
		}
	end

	def voc_count
		render json: {
			voc_count:Feedback
			.joins(retail_company_branch: :retail_company)
			.where({retail_companies:{project_id:current_user.project_id}}).count
		}
	end

	def list_promoter_in_project
		render json: Promoter.joins(retail_company_branch: [:retail_company,:city]).where(retail_companies:{project_id:current_user.project_id}).select("promoters.*,cities.city_name")
	end

	def get_gallery_of_merch
		  project_id = current_user.project_id
      data = {}
      data[:city_id] = params[:city_id].blank? ? City.where(project_id: project_id).pluck(:id) : params[:city_id]
      data[:retail_id] = params[:retail_id].blank? ? RetailCompany.where(project_id: project_id).pluck(:id) : params[:retail_id]
      data[:branch_id] = params[:branch_id].blank? ? RetailCompanyBranch.joins(:retail_company)
      .where(retail_companies: {project_id: project_id}).pluck(:id) : params[:branch_id]
      data[:start_date] = params[:start_date].blank? ? Date.today-30 : Date.parse(params[:start_date])
      data[:end_date] = params[:end_date].blank? ? Date.today : Date.parse(params[:end_date])
      selection = params[:selection]
      data[:role_id] = 2


      if (selection.blank? or selection == '' )
        gallery = gallery_query(data)
        selfie = selfie_query(data)
        power_wings = power_wings_query(data)
        planogram = planogram_query(data)
        render json: [{name: 'Gallery' , images: gallery} , {name:'Selfie' , images:selfie},
          {name: 'Power Wings' , images: power_wings} , {name: 'Planogram' , images:planogram}] 

      elsif selection == 1
        gallery = gallery_query(data)
        render json: [{name: 'Gallery' , images: gallery} ] 

      elsif  selection == 2
        selfie = selfie_query(data)
        render json: [{name:'Selfie' , images:selfie}] 
      elsif  selection == 3
        power_of_wings_photos = power_wings_query(data)
        render json: [{name:'Power Wings' , images:power_of_wings_photos}] 
      elsif selection == 4
        planogram = planogram_query(data)
        render json: [{name:'Planogram' , images:planogram}]   

      end
          
  	end

    def planogram_query(data)
      before_images = PlanogramBeforeImage.joins(jcp_implementation: {promoter_branch_day: [:promoter , :retail_company_branch]}).where(
        created_at: data[:start_date].beginning_of_day ..data[:end_date].end_of_day , promoter_branch_days:{
          retail_company_branch_id: data[:branch_id]} , retail_company_branches: {city_id: data[:city_id] , 
            retail_company_id: data[:retail_id]}).select('DATE_FORMAT(planogram_before_images.created_at,"%Y-%m-%d") as Date ,
        TIME_FORMAT(planogram_before_images.created_at, "%H:%i:%s") as Time ,promoters.username as promoter_name , 
        promoters.id as promoter_id , retail_company_branches.branch_name , planogram_before_images.id , planogram_before_images.image_before as image_path , 
        promoters.image as promoter_image ')
      after_images = PlanogramAfterImage.joins(jcp_implementation: {promoter_branch_day: [:promoter , :retail_company_branch]}).where(
        created_at: data[:start_date].beginning_of_day ..data[:end_date].end_of_day , promoter_branch_days:{
          retail_company_branch_id: data[:branch_id]} , retail_company_branches: {city_id: data[:city_id] , 
            retail_company_id: data[:retail_id]}).select('DATE_FORMAT(planogram_after_images.created_at,"%Y-%m-%d") as Date ,
        TIME_FORMAT(planogram_after_images.created_at, "%H:%i:%s") as Time ,promoters.username as promoter_name , 
        promoters.id as promoter_id , retail_company_branches.branch_name , planogram_after_images.id , planogram_after_images.image_after as image_path , 
        promoters.image as promoter_image ')

      return after_images + before_images
    end

    def power_wings_query(data)
      return PowerOfWingsPhoto.joins(promoter_branch_day: [:promoter , :retail_company_branch]).where(
        created_at: data[:start_date].beginning_of_day .. data[:end_date].end_of_day , 
        promoter_branch_days:{retail_company_branch_id: data[:branch_id]} , retail_company_branches: {retail_company_id:
          data[:retail_id] , city_id: data[:city_id]}).select('DATE_FORMAT(power_of_wings_photos.created_at,"%Y-%m-%d") as Date ,
        TIME_FORMAT(power_of_wings_photos.created_at, "%H:%i:%s") as Time ,promoters.username as promoter_name , 
        promoters.id as promoter_id , retail_company_branches.branch_name , power_of_wings_photos.id , power_of_wings_photos.image as image_path , 
        promoters.image as promoter_image ')
    

    end


  	def get_gallery_of_promoter
  		project_id = current_user.project_id
      data = {}
      data[:city_id] = params[:city_id].blank? ? City.where(project_id: project_id).pluck(:id) : params[:city_id]
      data[:retail_id] = params[:retail_id].blank? ? RetailCompany.where(project_id: project_id).pluck(:id) : params[:retail_id]
      data[:branch_id] = params[:branch_id].blank? ? RetailCompanyBranch.joins(:retail_company)
      .where(retail_companies: {project_id: project_id}).pluck(:id) : params[:branch_id]
      data[:start_date] = params[:start_date].blank? ? Date.today-30 : Date.parse(params[:start_date])
      data[:end_date] = params[:end_date].blank? ? Date.today : Date.parse(params[:end_date])
      selection = params[:selection]
      data[:role_id] = 1

      if (selection.blank? or selection == '' )
  	    gallery = gallery_query(data)
  		  selfie = selfie_query(data)
    		render json: [{name: 'Gallery' , images: gallery} , {name:'Selfie' , images:selfie}] 
  	  elsif selection == 1
        gallery = gallery_query(data)
        render json: [{name: 'Gallery' , images: gallery}]
      elsif selection == 2
        selfie = selfie_query(data)
        render json: [{name: 'Selfie' , images: selfie}]
      end

  end

    

  	def get_promoters_in_branch
  		render json: Promoter.joins(retail_company_branch: :city).where(retail_company_branch_id:params[:branch_id])
  			.select("promoters.*,cities.city_name")
  	end

  	def delete_promoter
  		promoter=Promoter.find(params[:promoter_id])
    	promoter.destroy
  end

  def assign_promoter_to_branch
  	dates = params[:dates]
  	dates.each do |jcp_date|
  		verify_id = PromoterBranchDay.find_by(promoter_id:params[:promoter_id], retail_company_branch_id: params[:branch_id],jcp_date: jcp_date)
  		
  		if(!verify_id)
  			assign_promoter = PromoterBranchDay.new(promoter_id: params[:promoter_id],retail_company_branch_id: params[:branch_id],jcp_date: jcp_date)
  			assign_promoter.save
  		end

  	end
  		render json:{message: "success added"}, status: "200"
  end

  def list_retails
  	companies = RetailCompany.where(project_id:current_user.project_id)
  	render json: companies
  end

  def list_branches
  	branches = RetailCompanyBranch.where(retail_company_id: params[:retail_id])
  	render json: branches
  end

  def promoter_profile
  	promoter=Promoter.find(params[:promoter_id])
  	render json: promoter,methods: [:jcp]
  end

  def list_gcp
    project_id = current_user.project_id
    date_range = get_date_range(params[:start_date],params[:end_date])
      branch_conditions = {}
    branch_conditions[:id] = params[:branch_id].blank? ? RetailCompanyBranch.joins(:retail_company)
      .where(retail_companies: {project_id: project_id},retail_company_branches:{is_deleted:"0"}).map(&:id) : params[:branch_id]
    is_visited=params[:is_visited].blank? ? [1,0] : params[:is_visited]
  	
    all_jcp = PromoterBranchDay.joins(retail_company_branch: [:retail_company,:store_class,:city]).joins(:promoter)
      .where(promoter_id: params[:promoter_id])
      .where(promoter_branch_days:date_range)
      .where(promoter_id:params[:promoter_id],
        is_visited: is_visited)
      .where(retail_company_branches:branch_conditions)
  	   .select("promoter_branch_days.*,retail_company_branches.branch_name,retail_companies.retail_company_name,cities.city_name,store_classes.class_name")
  	   .order("promoter_branch_days.jcp_date DESC")

    all_jcp_count=PromoterBranchDay.joins(retail_company_branch: [:retail_company,:store_class,:city]).joins(:promoter)
      .where(promoter_id: params[:promoter_id])
      .where(promoter_branch_days:date_range)
      .where(promoter_id:params[:promoter_id])
      .where(retail_company_branches:branch_conditions).count
      
  	promoter=Promoter.find(params[:promoter_id])

  	render json: {jcp_list:JSON.parse(all_jcp.to_json(:methods=>[:is_checked,:get_duration_of_jcp,:get_items_numbers,:get_planogram_categories])),promoter_info:promoter,
  		max_visit_date:(Date.civil(Date.today.year, Integer((Date.today+ 1.months).strftime("%m")) , -1)).strftime("%d/%m/%Y"),
  		all_visits: all_jcp_count
  	}
  end

  def delete_jcp
  	jcp = PromoterBranchDay.find(params[:jcp_id])
  	if jcp.destroy
      	render json: {'msg': 'deleted successfully!'}
    end
  end

  def list_jcp_details
  	visit_id = params[:visit_id]
  	category_id = params[:category_id]


  	jcp = JcpImplementation.find_by(category_id:category_id,  promoter_branch_day_id: visit_id)
  	render json: jcp,methods: [:get_image_before,:get_image_after,:get_category_name,:get_all_planograms,:get_reason]
  end

  def view_report_access
    render json: UsersAccessReport.joins(:reports_access_key)
                    .where(users_access_reports:{user_id: params[:client_id]})
                    .select("reports_access_keys.*").map(&:access_key)

  end

  private

  

  def get_percentage(part,total)
    if (total == 0)
      '--'
    else
      (Float((part*1.0)/total)).round(2)
    end
  end

  def get_date_range(start_date_param,end_date_param)
    date_range={}

    if start_date_param
      start_date=Date.parse(params[:start_date]).beginning_of_day
    else
      start_date=Date.today.beginning_of_day
    end

    if end_date_param
      end_date=Date.parse(params[:end_date]).end_of_day
    else
      end_date=Date.today.end_of_day
    end

    date_range[:jcp_date]=start_date .. end_date
    date_range
  end
  def gallery_query(data)
      return BranchImage.joins(:promoter , :retail_company_branch)
          .where(retail_company_branches: {id: data[:branch_id],retail_company_id:data[:retail_id],city_id:data[:city_id]})
          .where(created_at: data[:start_date].beginning_of_day .. data[:end_date].end_of_day , promoters: {promoter_role_id:data[:role_id]}).select('
            DATE_FORMAT(branch_images.created_at,"%Y-%m-%d") as Date , TIME_FORMAT(branch_images.created_at, "%H:%i:%s") as Time , 
            promoters.username as promoter_name ,branch_images.id, retail_company_branches.branch_name , promoters.image  as promoter_image , promoters.id as promoter_id,
            branch_images.image_path')
      
    end

    def selfie_query(data)
      return PromoterCheckIn.joins(:promoter,promoter_branch_day: :retail_company_branch ).where(retail_company_branches:{
        city_id: data[:city_id] , retail_company_id: data[:retail_id] , id: data[:branch_id]} , created_at:
        data[:start_date].beginning_of_day ..data[:end_date].end_of_day,promoters: {promoter_role_id:data[:role_id]}).select('DATE_FORMAT(promoter_check_ins.created_at,"%Y-%m-%d") as Date ,
        TIME_FORMAT(promoter_check_ins.created_at, "%H:%i:%s") as Time , promoters.username as promoter_name , 
        retail_company_branches.branch_name , promoters.image as promoter_image , promoter_check_ins.id , promoter_check_ins.promoter_id , 
        promoter_check_ins.image_path')
    end

end
