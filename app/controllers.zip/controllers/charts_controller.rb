class ChartsController < ApplicationController

  before_action :authenticate_user! ,except: [:get_missing_visits]



    def samples_chart
      project_id = current_user.project_id
      start_date = params[:start_date].blank? ? (Date.today-7).beginning_of_day 
      : Date.parse(params[:start_date]).beginning_of_day
      end_date = params[:end_date].blank? ? Date.today.end_of_day 
      : Date.parse(params[:end_date]).end_of_day
      samples_percentage_with_dates = get_samples_percentage_with_date(project_id)
      samples_percentage_vs_city = get_samples_percentage_vs_city(project_id,start_date,end_date)
	  samples_percentage_vs_chain = get_samples_percentage_vs_chain(project_id,start_date,end_date)
	  samples_percentage_vs_store = get_samples_percentage_vs_store(project_id,start_date,end_date)
	  render json: {
	  	'samples_percentage_with_dates': samples_percentage_with_dates,
	  	'branch': samples_percentage_vs_store,'chain': samples_percentage_vs_chain,
	  	'city': samples_percentage_vs_city}

    end 


    def engagement_chart
      project_id = current_user.project_id
      start_date = params[:start_date].blank? ? (Date.today-7).beginning_of_day 
      : Date.parse(params[:start_date]).beginning_of_day
      end_date = params[:end_date].blank? ? Date.today.end_of_day 
      : Date.parse(params[:end_date]).end_of_day
      engagement_percentage_with_dates = get_engagement_percentage_with_date(project_id)
      engagement_percentage_vs_city = get_engagement_percentage_vs_city(project_id,start_date,end_date)
	  engagement_percentage_vs_chain = get_engagement_percentage_vs_chain(project_id,start_date,end_date)
	  engagement_percentage_vs_store = get_engagement_percentage_vs_store(project_id,start_date,end_date)
	  render json: {
	  	'engagement_percentage_with_dates': engagement_percentage_with_dates,
	  	'branch': engagement_percentage_vs_store,'chain': engagement_percentage_vs_chain,
	  	'city': engagement_percentage_vs_city}

    end

    def promoter_jcp_visits_chart
      project_id = current_user.project_id
      start_date = params[:start_date].blank? ? (Date.today-7) 
      : Date.parse(params[:start_date])
      end_date = params[:end_date].blank? ? Date.today 
      : Date.parse(params[:end_date])
      jcp_percentage_with_dates = get_promoter_jcp_visits_with_date(project_id,start_date,end_date)
	  jcp_visits_percentage_vs_city = get_promoter_jcp_visits_vs_city(project_id,start_date,end_date)
	  jcp_visits_percentage_vs_chain = get_promoter_jcp_visits_vs_chain(project_id,start_date,end_date)
	  jcp_visits_percentage_vs_store = get_promoter_jcp_visits_vs_store(project_id,start_date,end_date)
	  render json: {'jcp_percentage_with_dates': jcp_percentage_with_dates,'city': 
	  	jcp_visits_percentage_vs_city , 'chain': jcp_visits_percentage_vs_chain,
	  	'branch': jcp_visits_percentage_vs_store}

    end

    def promoter_sales_by_price
      project_id = current_user.project_id
      start_date = params[:start_date].blank? ? (Date.today-7).beginning_of_day 
      : Date.parse(params[:start_date]).beginning_of_day
      end_date = params[:end_date].blank? ? Date.today.end_of_day 
      : Date.parse(params[:end_date]).end_of_day
      promoter_sales_with_dates = get_promoter_sales_by_price_with_dates(project_id)
      promoter_sales_vs_city = get_promoter_sales_by_price_vs_city(project_id,start_date,end_date)
      promoter_sales_vs_chain = get_promoter_sales_by_price_vs_chain(project_id,start_date,end_date)
      promoter_sales_vs_store = get_promoter_sales_by_price_vs_store(project_id,start_date,end_date)

      render json: {'promoter_sales_with_dates': promoter_sales_with_dates,
      	'promoter_sales_vs_city': promoter_sales_vs_city,'promoter_sales_vs_chain':
        promoter_sales_vs_chain,'promoter_sales_vs_store': promoter_sales_vs_store}
    end


    def promoter_sales_by_quantity
      project_id = current_user.project_id
      start_date = params[:start_date].blank? ? (Date.today-7).beginning_of_day 
      : Date.parse(params[:start_date]).beginning_of_day
      end_date = params[:end_date].blank? ? Date.today.end_of_day 
      : Date.parse(params[:end_date]).end_of_day
      promoter_sales_with_dates = get_promoter_sales_by_quantity_with_dates(project_id)
      promoter_sales_vs_city = get_promoter_sales_by_quantity_vs_city(project_id,start_date,end_date)
      promoter_sales_vs_chain = get_promoter_sales_by_quantity_vs_chain(project_id,start_date,end_date)
      promoter_sales_vs_store = get_promoter_sales_by_quantity_vs_store(project_id,start_date,end_date)
      promoter_sales_vs_category = get_promoter_sales_by_quantity_vs_category(project_id,start_date,end_date)

      render json: {'promoter_sales_with_dates': promoter_sales_with_dates,
      	'promoter_sales_vs_city': promoter_sales_vs_city,'promoter_sales_vs_chain':
        promoter_sales_vs_chain,'promoter_sales_vs_store': promoter_sales_vs_store,
        'promoter_sales_vs_category': promoter_sales_vs_category}
    end

  	def planogram_chart
  		project_id = current_user.project_id
  		start_date = params[:start_date].blank? ? (Date.today-7).beginning_of_day 
        : Date.parse(params[:start_date]).beginning_of_day
        end_date = params[:end_date].blank? ? Date.today.end_of_day 
        : Date.parse(params[:end_date]).end_of_day

  		count_of_categories = Planogram.joins(:category)
  		.where(categories: {project_id: project_id})
  		.select(:category_id).distinct.count
  		categories = Planogram.joins(:category).where(categories: {project_id: project_id}).pluck(:category_id)
  		planogram_percentage_with_dates = get_planogram_percentage_with_dates(categories,count_of_categories,project_id)  		
  		planogram_vs_store = get_planogram_implementation_percentage_vs_store(categories,count_of_categories,project_id,start_date,end_date)
  		planogram_vs_city = get_planogram_implementation_percentage_vs_city(planogram_vs_store,project_id)
  		planogram_vs_chain = get_planogram_implementation_percentage_vs_chain(planogram_vs_store,project_id)
  		render json: {'planogram_percentage_with_dates': planogram_percentage_with_dates ,'planogram_vs_city': planogram_vs_city, 'planogram_vs_chain': planogram_vs_chain , 'planogram_vs_store': planogram_vs_store}
  	end

  	def MSL_chart
  		project_id = current_user.project_id
  		start_date = params[:start_date].blank? ? (Date.today-7).beginning_of_day 
        : Date.parse(params[:start_date]).beginning_of_day
        end_date = params[:end_date].blank? ? Date.today.end_of_day 
        : Date.parse(params[:end_date]).end_of_day
		msl_percentage_with_dates = get_MSL_percentage_with_dates(project_id)
		city_percentage = get_citis_vs_msl(project_id,start_date,end_date)
		chain_percentage = get_chains_vs_msl(project_id,start_date,end_date)
		branch_percentage = get_branches_vs_msl(project_id,start_date,end_date)
		render json: {'msl_percentages_with_dates': msl_percentage_with_dates,'city': city_percentage ,'chain': chain_percentage , 'branch': branch_percentage} , status: 200

	end

	def missing_today_percentage(project_id)
		all_today_visits=PromoterBranchDay.joins(:promoter ,{retail_company_branch: :retail_company})
						.where(jcp_date: Date.today.beginning_of_day .. Date.today.end_of_day)
						.where(retail_companies: {project_id: project_id})
						.where(retail_company_branches: {is_deleted: 0} )
						.where(promoters:{promoter_role_id: 2})
		checked_in_jcps = PromoterCheckIn.where(promoter_branch_day_id: all_today_visits.ids).count
		not_checked_in=all_today_visits.count - checked_in_jcps
		percentage = get_percentage(not_checked_in , all_today_visits.count)
		percentage
	end

	def missing_week_percentage(project_id)
		all_week_visits=PromoterBranchDay.joins(:promoter ,retail_company_branch: :retail_company)
		.where(jcp_date: (Date.today - 7).beginning_of_day .. Date.today.end_of_day)
		.where(retail_companies: {project_id: project_id})
		.where(retail_company_branches: {is_deleted: 0} )
		.where(promoters:{promoter_role_id: 2})

		checked_in_jcps = PromoterCheckIn.where(promoter_branch_day_id: all_week_visits.ids).count
		not_checked_in=all_week_visits.count - checked_in_jcps
		percentage = get_percentage(not_checked_in , all_week_visits.count)
		percentage
	end

	def missing_month_percentage(project_id)
		all_month_visits=PromoterBranchDay.joins(:promoter ,retail_company_branch: :retail_company)
						.where(jcp_date: (Date.today - 30).beginning_of_day .. Date.today.end_of_day)
						.where(retail_companies: {project_id: project_id})
						.where(promoters:{promoter_role_id: 2})
						.where(retail_company_branches: {is_deleted: 0} )

		checked_in_jcps = PromoterCheckIn.where(promoter_branch_day_id: all_month_visits.ids).count
		not_checked_in=all_month_visits.count - checked_in_jcps
		percentage = get_percentage(not_checked_in , all_month_visits.count)
		percentage
	end

	def missing_by_ksa(project_id, start_date , end_date)
		all_ksa_visits = PromoterBranchDay.joins(:promoter , retail_company_branch: :retail_company)
		.where(jcp_date: start_date .. end_date)
		.where(retail_companies: {project_id: project_id})
		.where(promoters: {promoter_role_id: 2})
		.where(retail_company_branches: {is_deleted: 0})
		checked_in_jcps = PromoterCheckIn.where(promoter_branch_day_id: all_ksa_visits).count
		not_checked_in = all_ksa_visits.count - checked_in_jcps
		percentage = get_percentage(not_checked_in , all_ksa_visits.count)

	end

	def get_missing_visits
		project_id = current_user.project_id
		start_date = params[:start_date].blank? ? (Date.today-7).beginning_of_day 
        : Date.parse(params[:start_date]).beginning_of_day
        end_date = params[:end_date].blank? ? Date.today.end_of_day 
        : Date.parse(params[:end_date]).end_of_day
		
		render json: {
			'missing_by_ksa': missing_by_ksa(project_id , start_date , end_date),
			'missing_today_percentage': missing_today_percentage(project_id),
			'missing_week_percentage': missing_week_percentage(project_id),
			'month_percentage': missing_month_percentage(project_id),
			'unvisited_by_city': get_missing_visit_by_cities(project_id,start_date,end_date),
			'unvisited_by_chain': get_missing_visit_by_chain(project_id,start_date,end_date),
			'unvisited_by_store': get_missing_visit_by_branch(project_id,start_date,end_date)
		}
		

	end

	def jcp_chart
		project_id = current_user.project_id
		start_date = params[:start_date].blank? ? (Date.today-7) 
        : Date.parse(params[:start_date])
        end_date = params[:end_date].blank? ? Date.today 
        : Date.parse(params[:end_date])

		jcp_percentage_with_dates = jcp_chart_with_date(project_id,start_date,end_date)
		jcp_visits_percentage_vs_city = get_jcp_visits_vs_city(project_id,start_date,end_date)
		jcp_visits_percentage_vs_chain = get_jcp_visits_vs_chain(project_id,start_date,end_date)
		jcp_visits_percentage_vs_store = get_jcp_visits_vs_store(project_id,start_date,end_date)
		render json: {'jcp_percentage_with_dates': jcp_percentage_with_dates,'city': jcp_visits_percentage_vs_city , 'chain': jcp_visits_percentage_vs_chain,'branch': jcp_visits_percentage_vs_store}
	end






	private
	###################### samples chart ########################################

	def get_samples_percentage_with_date(project_id)
      mtd_samples = Sample.joins(promoter_branch_day: {retail_company_branch: :city})
      .where(cities: {project_id: project_id}).where('samples.created_at >= ? AND 
			samples.created_at <= ?',(Date.today- 30).beginning_of_day , 
			Date.today.end_of_day)
      wtd_samples = mtd_samples.where('samples.created_at >= ? AND 
			samples.created_at <= ?',(Date.today- 7).beginning_of_day , 
			Date.today.end_of_day)
      today_samples = mtd_samples.where('samples.created_at >= ? AND 
			samples.created_at <= ?',Date.today.beginning_of_day , 
			Date.today.end_of_day)
      return {'mtd_samples': mtd_samples.sum(:distributed_samples),'wtd_samples': wtd_samples.sum(:distributed_samples),
      	'today_samples': today_samples.sum(:distributed_samples)}			
    end

	def get_samples_percentage_vs_city(project_id,start_date,end_date)
      cities = City.where(project_id: project_id)
	  city_percentage = []
	  cities.each do |city|
	  	samples = Sample.joins(promoter_branch_day: {retail_company_branch: 
	  		:city}).where(cities:{id: city.id}).where('samples.created_at >= ? AND 
			samples.created_at <= ?',start_date , end_date).sum(:distributed_samples)
	  	city_percentage << {'city': city.city_name,'samples': samples}

	  end
	  return city_percentage

	end

	def get_samples_percentage_vs_chain(project_id,start_date,end_date)
      chains = RetailCompany.where(project_id: project_id)
	  chain_percentage = []
	  chains.each do |chain|
	  	samples = Sample.joins(promoter_branch_day: {retail_company_branch: 
	  		:retail_company}).where(retail_companies:{id: chain.id}).where(
	  		'samples.created_at >= ? AND samples.created_at <= ?',
	  		start_date , end_date).sum(:distributed_samples)
	  	chain_percentage << {'chain': chain.retail_company_name,'samples': samples}

	  end
	  return chain_percentage
	end



	def get_samples_percentage_vs_store(project_id,start_date,end_date)
		branches = RetailCompanyBranch.joins(:retail_company)
	    .where(retail_companies:{project_id:project_id})
	    branch_percentage = []
	  branches.each do |branch|
	  	samples = Sample.joins(promoter_branch_day: :retail_company_branch).where(
	  		retail_company_branches:{id: branch.id}).where('samples.created_at >= ? AND 
			samples.created_at <= ?',start_date , end_date).sum(:distributed_samples)
	  	branch_percentage << {'branch': branch.branch_name,'samples': samples}

	  end
	  return branch_percentage
	end

	###################### engagement chart #####################################
    def get_engagement_percentage_with_date(project_id)
      mtd_engagement = CustomerEngagement.joins(promoter_branch_day: {retail_company_branch: :city})
      .where(cities: {project_id: project_id}).where('customer_engagements.created_at >= ? AND 
			customer_engagements.created_at <= ?',(Date.today- 30).beginning_of_day , 
			Date.today.end_of_day)
      wtd_engagement = mtd_engagement.where('customer_engagements.created_at >= ? AND 
			customer_engagements.created_at <= ?',(Date.today- 7).beginning_of_day , 
			Date.today.end_of_day)
      today_engagement = mtd_engagement.where('customer_engagements.created_at >= ? AND 
			customer_engagements.created_at <= ?',Date.today.beginning_of_day , 
			Date.today.end_of_day)
      return {'mtd_engagement': mtd_engagement.count,'wtd_engagement': wtd_engagement.count,
      	'today_engagement': today_engagement.count}			
    end

	def get_engagement_percentage_vs_city(project_id,start_date,end_date)
      cities = City.where(project_id: project_id)
	  city_percentage = []
	  cities.each do |city|
	  	engagements = CustomerEngagement.joins(promoter_branch_day: {retail_company_branch: 
	  		:city}).where(cities:{id: city.id}).where('customer_engagements.created_at >= ? AND 
			customer_engagements.created_at <= ?',start_date , end_date).count
	  	city_percentage << {'city': city.city_name,'engagements': engagements}

	  end
	  return city_percentage

	end


	def get_engagement_percentage_vs_chain(project_id,start_date,end_date)
      chains = RetailCompany.where(project_id: project_id)
	  chain_percentage = []
	  chains.each do |chain|
	  	engagements = CustomerEngagement.joins(promoter_branch_day: {retail_company_branch: 
	  		:retail_company}).where(retail_companies:{id: chain.id}).where(
	  		'customer_engagements.created_at >= ? AND customer_engagements.created_at <= ?',
	  		start_date , end_date).count
	  	chain_percentage << {'chain': chain.retail_company_name,'engagements': engagements}

	  end
	  return chain_percentage
	end

	def get_engagement_percentage_vs_store(project_id,start_date,end_date)
		branches = RetailCompanyBranch.joins(:retail_company)
	    .where(retail_companies:{project_id:project_id})
	    branch_percentage = []
	  branches.each do |branch|
	  	engagements = CustomerEngagement.joins(promoter_branch_day: :retail_company_branch).where(
	  		retail_company_branches:{id: branch.id}).where('customer_engagements.created_at >= ? AND 
			customer_engagements.created_at <= ?',start_date , end_date).count
	  	branch_percentage << {'branch': branch.branch_name,'engagements': engagements}

	  end
	  return branch_percentage
	end

	###################### ptomoter jcp visits #################################
	def get_promoter_jcp_visits_vs_store(project_id,start_date,end_date)
	  branches = RetailCompanyBranch.joins(:retail_company)
	    .where(retail_companies:{project_id:project_id})
		  .where(retail_company_branches:{is_deleted: 0})

	  branch_percentage = []
	  branches.each do |branch|
		all_jcp = PromoterBranchDay.joins(:promoter).where(retail_company_branch_id: branch.id ,
		  promoters: {promoter_role_id: 1} ).where('
		  	promoter_branch_days.jcp_date >= ? AND promoter_branch_days.jcp_date <= ?', start_date ,end_date)
		checked_in_jcps = PromoterCheckIn.where(promoter_branch_day_id: all_jcp.ids)
		percentage = get_percentage(checked_in_jcps.count*1.0, all_jcp.count)
		branch_percentage << {'branch': branch.branch_name , 'percentage': percentage.to_s + '%'}
	  end
	  return branch_percentage
	end

	def get_promoter_jcp_visits_vs_chain(project_id,start_date,end_date)
      chains = RetailCompany.where(project_id: project_id)
	  chain_percentage = []
	  chains.each do |chain|
		all_jcp = PromoterBranchDay.joins(:retail_company_branch,:promoter)
		  .where(retail_company_branches: {retail_company_id: chain.id}, 
		  promoters: {promoter_role_id:1} ).where('
		  	promoter_branch_days.jcp_date >= ? AND promoter_branch_days.jcp_date <= ?', start_date ,end_date)
		  .where(retail_company_branches:{is_deleted: 0})
		checked_in_jcps = PromoterCheckIn.where(promoter_branch_day_id: all_jcp.ids)
		percentage = get_percentage(checked_in_jcps.count*1.0 , all_jcp.count)
		chain_percentage << {'chain': chain.retail_company_name , 'percentage': percentage.to_s + '%'}
	  end
	  return chain_percentage
	end

	def get_promoter_jcp_visits_vs_city(project_id,start_date,end_date)
	  # actual / planned
  	  cities = City.where(project_id: project_id)
  	  city_percentage = []
	  cities.each do |city|
		all_jcp = PromoterBranchDay.joins(:retail_company_branch,:promoter)
		  .where(retail_company_branches: {city_id: city.id} , promoters:{promoter_role_id:1}).where('
		  	promoter_branch_days.jcp_date >= ? AND promoter_branch_days.jcp_date <= ?', start_date ,end_date)
		  .where(retail_company_branches:{is_deleted: 0})
		checked_in_jcps = PromoterCheckIn.where(promoter_branch_day_id: all_jcp.ids)
		percentage = get_percentage(checked_in_jcps.count*1.0 , all_jcp.count)
		city_percentage << {'city': city.city_name , 'percentage': percentage.to_s + '%'}
	  end
	  return city_percentage
	end


	def get_promoter_jcp_visits_with_date(project_id,start_date,end_date)
	  all_jcp = PromoterBranchDay.joins(:promoter , retail_company_branch: :city)
		.where(cities:{project_id:project_id},promoters:{promoter_role_id: 1} )
		.where(retail_company_branches:{is_deleted: 0})
	  jcp_ksa = all_jcp.where(jcp_date: start_date .. end_date)
	  checked_in_jcp_ksa = PromoterCheckIn.where(promoter_branch_day_id: jcp_ksa.ids) 
	  percentage_of_ksa = get_percentage(checked_in_jcp_ksa.count*1.0 , jcp_ksa.count)		
  	  all_jcp_today = all_jcp.where(jcp_date: Date.today.beginning_of_day .. 
  		Date.today.end_of_day)
  	  checked_in_jcps_today = PromoterCheckIn.where(promoter_branch_day_id: all_jcp_today.ids)
  	  jcp_percentage_today = get_percentage(checked_in_jcps_today.count*1.0 , all_jcp_today.count)
  	  all_jcp_wtd = all_jcp.where(jcp_date: (Date.today - 7).beginning_of_day ..
  	  	Date.today.end_of_day)
  	  checked_in_jcps_wtd = PromoterCheckIn.where(promoter_branch_day_id: all_jcp_wtd.ids)
  	  jcp_percentage_wtd = get_percentage(checked_in_jcps_wtd.count*1.0 , all_jcp_wtd.count)
	  all_jcp_mtd = all_jcp.where(jcp_date: (Date.today - 30).beginning_of_day ..
	  	Date.today.end_of_day)
  	  checked_in_jcps_mtd = PromoterCheckIn.where(promoter_branch_day_id: all_jcp_mtd.ids)
  	  jcp_percentage_mtd = get_percentage(checked_in_jcps_mtd.count*1.0 , all_jcp_mtd.count)
  	  return {'percentage_of_ksa': percentage_of_ksa,'jcp_percentage_today': jcp_percentage_today,'jcp_percentage_wtd': 
  	  	jcp_percentage_wtd,'jcp_percentage_mtd': jcp_percentage_mtd}
	end

	###################### promoter sales by price ###########################
	def get_promoter_sales_by_price_with_dates(project_id)
	  promoter_sales_price = InvoiceDevice.joins(invoice: {retail_company_branch: :city})
	  .where('cities.project_id = ?' , project_id )
  	  promoter_sales_price_today = promoter_sales_price.where(created_at: 
  		Date.today.beginning_of_day .. Date.today.end_of_day).sum("price*quantity")
  	  promoter_sales_price_wtd = promoter_sales_price.where(created_at: 
  		(Date.today - 7).beginning_of_day ..Date.today.end_of_day).sum("price*quantity")
	  promoter_sales_price_mtd = promoter_sales_price.where(created_at: 
		(Date.today - 30).beginning_of_day ..Date.today.end_of_day).sum("price*quantity")
  	  return {'promoter_sales_price_today': promoter_sales_price_today,
  		'promoter_sales_price_wtd': promoter_sales_price_wtd,'promoter_sales_price_mtd': 
  		promoter_sales_price_mtd}
	end

	def get_promoter_sales_by_price_vs_store(project_id,start_date,end_date)
	  branches = RetailCompanyBranch.joins(:retail_company).where('retail_companies.project_id =
	   ?' ,project_id)
	  sales_price = []
	  branches.each do |branch|
		price = InvoiceDevice.joins(:invoice).where(invoices:{retail_company_branch_id:
		branch.id }).where('invoice_devices.created_at >= ? AND 
			invoice_devices.created_at <= ?', start_date ,end_date)
		.sum("price*quantity")
		sales_price << {'branch': branch.branch_name , 'price': price}
	  end
	  return sales_price
	end

	def get_promoter_sales_by_price_vs_chain(project_id,start_date,end_date)
	  chains = RetailCompany.where(project_id: project_id) 
	  sales_price = []
	  chains.each do |chain|
	  	price = InvoiceDevice.joins(invoice: :retail_company_branch)
		.where(retail_company_branches: {retail_company_id: chain.id}).where('invoice_devices.created_at 
			>= ? AND invoice_devices.created_at <= ?', start_date ,end_date).sum("price*quantity")
		sales_price << {'chain': chain.retail_company_name , 'price': price}
	  end
	  return sales_price
	end

	def get_promoter_sales_by_price_vs_city(project_id,start_date,end_date)
  	  cities = City.where(project_id: project_id)
  	  sales_price = []
	  cities.each do |city|
		price = InvoiceDevice.joins(invoice: :retail_company_branch)
		.where(retail_company_branches:{city_id: city.id} ).where('invoice_devices.created_at >= ? AND 
			invoice_devices.created_at <= ?', start_date ,end_date).sum("price*quantity")
		sales_price << {'city': city.city_name , 'price': price}
	  end
	  return sales_price
	end


	###################### promoter sales by quantity ########################
    def get_promoter_sales_by_quantity_vs_category(project_id,start_date,end_date)
      categories = Category.where(project_id: project_id)
      sales_quantity = []
      categories.each do |category|
      	quantity = InvoiceDevice.joins(device: :item).where(items: {category_id: category.id})
      	.where('invoice_devices.created_at >= ? AND invoice_devices.created_at <= ?', 
      		start_date ,end_date).sum(:quantity)
      	sales_quantity << {'category': category.category_name , 'quantity': quantity}	
      end
      return sales_quantity
    end

	def get_promoter_sales_by_quantity_with_dates(project_id)
	  promoter_sales_quantity = InvoiceDevice.joins(invoice: {retail_company_branch: :city})
	  .where('cities.project_id = ?' , project_id )
  	  promoter_sales_quantity_today = promoter_sales_quantity.where(created_at: 
  		Date.today.beginning_of_day .. Date.today.end_of_day).sum(:quantity)
  	  promoter_sales_quantity_wtd = promoter_sales_quantity.where(created_at: 
  		(Date.today - 7).beginning_of_day ..Date.today.end_of_day).sum(:quantity)
	  promoter_sales_quantity_mtd = promoter_sales_quantity.where(created_at: 
		(Date.today - 30).beginning_of_day ..Date.today.end_of_day).sum(:quantity)
  	  return {'promoter_sales_quantity_today': promoter_sales_quantity_today,
  		'promoter_sales_quantity_wtd': promoter_sales_quantity_wtd,'promoter_sales_quantity_mtd': 
  		promoter_sales_quantity_mtd}
	end

	def get_promoter_sales_by_quantity_vs_store(project_id,start_date,end_date)
	  branches = RetailCompanyBranch.joins(:retail_company).where('retail_companies.project_id =
	   ?' ,project_id)
	  sales_quantity = []
	  branches.each do |branch|
		quantity = InvoiceDevice.joins(:invoice).where(invoices:{retail_company_branch_id:
		branch.id })
        .where('invoice_devices.created_at >= ? AND invoice_devices.created_at <= ?', start_date ,end_date)
		.sum(:quantity)
		sales_quantity << {'branch': branch.branch_name , 'quantity': quantity}
	  end
	  return sales_quantity
	end

	def get_promoter_sales_by_quantity_vs_chain(project_id,start_date,end_date)
	  chains = RetailCompany.where(project_id: project_id) 
	  sales_quantity = []
	  chains.each do |chain|
	  	quantity = InvoiceDevice.joins(invoice: :retail_company_branch)
		.where(retail_company_branches: {retail_company_id: chain.id})
        .where('invoice_devices.created_at >= ? AND invoice_devices.created_at <= ?', start_date ,end_date)
		.sum(:quantity)
		sales_quantity << {'chain': chain.retail_company_name , 'quantity': quantity}
	  end
	  return sales_quantity
	end

	def get_promoter_sales_by_quantity_vs_city(project_id,start_date,end_date)
  	  cities = City.where(project_id: project_id)
  	  sales_quantity = []
	  cities.each do |city|
		quantity = InvoiceDevice.joins(invoice: :retail_company_branch)
		.where(retail_company_branches:{city_id: city.id})
        .where('invoice_devices.created_at >= ? AND invoice_devices.created_at <= ?', start_date ,end_date)
		.sum(:quantity)
		sales_quantity << {'city': city.city_name , 'quantity': quantity}
	  end
	  return sales_quantity
	end

	###################### jcp chart #############################

	def jcp_chart_with_date(project_id,start_date,end_date)
		all_jcp = PromoterBranchDay.joins(:promoter ,{retail_company_branch: :retail_company}).where('retail_companies.project_id = ?' , project_id )
		.where(promoters: {promoter_role_id: 2})
		.where(retail_company_branches:{is_deleted: 0})
		all_ksa_visits = all_jcp.where(jcp_date: start_date.. end_date)
		checked_in_jcps_ksa = PromoterCheckIn.where(promoter_branch_day_id: all_ksa_visits.ids)
		ksa_percentage = get_percentage(checked_in_jcps_ksa.count , all_ksa_visits.count)		
  		all_jcp_today = all_jcp.where(jcp_date: Date.today.beginning_of_day .. Date.today.end_of_day)
  		checked_in_jcps_today = PromoterCheckIn.where(promoter_branch_day_id: all_jcp_today.ids)
  		jcp_percentage_today = get_percentage(checked_in_jcps_today.count*1.0 , all_jcp_today.count)
  		all_jcp_wtd = all_jcp.where(jcp_date: (Date.today - 7).beginning_of_day ..Date.today.end_of_day)
  		checked_in_jcps_wtd = PromoterCheckIn.where(promoter_branch_day_id: all_jcp_wtd.ids)
  		jcp_percentage_wtd = get_percentage(checked_in_jcps_wtd.count*1.0 , all_jcp_wtd.count)
		all_jcp_mtd = all_jcp.where(jcp_date: (Date.today - 30).beginning_of_day ..Date.today.end_of_day)
  		checked_in_jcps_mtd = PromoterCheckIn.where(promoter_branch_day_id: all_jcp_mtd.ids)
  		jcp_percentage_mtd = get_percentage(checked_in_jcps_mtd.count*1.0 , all_jcp_mtd.count)
  		return {'ksa_percentage': ksa_percentage , 'jcp_percentage_today': jcp_percentage_today,'jcp_percentage_wtd': jcp_percentage_wtd,'jcp_percentage_mtd': jcp_percentage_mtd}
	end

	def get_jcp_visits_vs_store(project_id,start_date,end_date)
		branches = RetailCompanyBranch.joins(:retail_company).where('retail_companies.project_id = ?' ,project_id) # change to current user
		branch_percentage = []
		branches.each do |branch|
			all_jcp = PromoterBranchDay.joins(:promoter).joins(:retail_company_branch).where(retail_company_branch_id: branch.id)
			.where(promoters:{promoter_role_id: 2})
			.where(retail_company_branches:{is_deleted: 0})
			.where('promoter_branch_days.jcp_date >= ? AND promoter_branch_days.jcp_date <= ?',
			 start_date,end_date)
			checked_in_jcps = PromoterCheckIn.where(promoter_branch_day_id: all_jcp.ids)
			percentage = get_percentage(checked_in_jcps.count*1.0, all_jcp.count)
			branch_percentage << {'branch': branch.branch_name , 'percentage': percentage.to_s+'%'}
		end
		return branch_percentage
	end

	def get_jcp_visits_vs_chain(project_id,start_date,end_date)
		chains = RetailCompany.where(project_id: project_id) # change to current user
		chain_percentage = []
		chains.each do |chain|
			all_jcp = PromoterBranchDay.joins(:promoter ,:retail_company_branch)
			.where(retail_company_branches: {retail_company_id: chain.id})
			.where(retail_company_branches:{is_deleted: 0})
			.where('promoter_branch_days.jcp_date >= ? AND promoter_branch_days.jcp_date <= ?',
			 start_date,end_date)
			.where(promoters: {promoter_role_id: 2})
			checked_in_jcps = PromoterCheckIn.where(promoter_branch_day_id: all_jcp.ids)
			percentage = get_percentage(checked_in_jcps.count*1.0 , all_jcp.count)
			chain_percentage << {'chain': chain.retail_company_name , 'percentage': percentage.to_s + '%'}
		end
		return chain_percentage
	end

	def get_jcp_visits_vs_city(project_id,start_date,end_date)
		# actual / planned
  		cities = City.where(project_id: project_id)
  		city_percentage = []
		cities.each do |city|
			all_jcp = PromoterBranchDay.joins(:promoter ,:retail_company_branch)
			.where(retail_company_branches: {city_id: city.id})
			.where(retail_company_branches:{is_deleted: 0})
      		.where('promoter_branch_days.jcp_date >= ? AND promoter_branch_days.jcp_date <= ?',
			 start_date,end_date)
      		.where(promoters: {promoter_role_id: 2})
			checked_in_jcps = PromoterCheckIn.where(promoter_branch_day_id: all_jcp.ids)
			percentage = get_percentage(checked_in_jcps.count*1.0 , all_jcp.count)
			city_percentage << {'city': city.city_name , 'percentage': percentage.to_s + '%'}
		end
		return city_percentage
	end

	###################### planogram chart #############################

  	def get_planogram_implementation_percentage_vs_city(planogram_vs_store,project_id)
  		cities = City.where(project_id: project_id)

  		city_percentage = []
		cities.each do |city|
			branches_percentage = []
  		  
  		  planogram_vs_store.each do |percentage_per_branch|
  		  	if percentage_per_branch[:city] == city.id  && percentage_per_branch[:percentage_number].is_a?(Numeric)
  		  	  branches_percentage << percentage_per_branch[:percentage_number].to_f
  		  	end
  		  end
  		  implementation_percentage = get_percentage(branches_percentage.sum*0.01 , branches_percentage.count )
  		  city_percentage << {city: city.city_name ,
			 percentage: implementation_percentage.to_s + '%'}
  		end
		return city_percentage

  	end

  	def get_planogram_implementation_percentage_vs_chain(planogram_vs_store,project_id)
  		chains = RetailCompany.where(project_id: project_id)
  		chain_percentage = []
  		chains.each do |chain|
  		  branches_percentage = []
  		  
  		  planogram_vs_store.each do |percentage_per_branch|
  		  	if percentage_per_branch[:retail] == chain.id && percentage_per_branch[:percentage_number].is_a?(Numeric)
  		  	  branches_percentage << percentage_per_branch[:percentage_number].to_f
  		  	end
  		  end
  		  implementation_percentage = get_percentage(branches_percentage.sum*0.01 , branches_percentage.count) 
  		  chain_percentage << {chain: chain.retail_company_name ,
			 percentage: implementation_percentage.to_s + '%'}
  		end
  	  return chain_percentage
  	 end 



  		

  	

  	def get_planogram_implementation_percentage_vs_store(categories,count_of_categories,project_id,start_date,end_date)
  		branches = RetailCompanyBranch.joins(:retail_company)
  		.where(retail_companies:{project_id: project_id})
  		store_percentage = []
  		branches.each do |branch|
  			jcps = PromoterBranchDay.joins(:promoter).where(retail_company_branch_id: branch.id)
      		.where('promoter_branch_days.jcp_date >= ? AND promoter_branch_days.jcp_date <= ?',
      		 start_date ,end_date).where(promoters:{promoter_role_id: 2} , is_visited: 1).pluck(:id)
  			jcp_percentage = []
			jcps.each do |jcp|
				planogram_implementation_per_jcp = JcpImplementation
				.where(promoter_branch_day_id: jcp , category_id: categories)
				.sum(:implementation_percentage)

				jcp_percentage << get_percentage(
					planogram_implementation_per_jcp*1.0/100 , count_of_categories)
				# print('jcp_percentageeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee')
				# print(jcp_percentage)
				
		end	
		

			avg_percentage_per_branch = get_percentage(jcp_percentage.sum*0.01 , jcp_percentage.count)
		
			store_percentage << {branch: branch.branch_name ,retail: branch.retail_company_id,
				 percentage: avg_percentage_per_branch.to_s + '%' , percentage_number: avg_percentage_per_branch,
				 city: branch.city_id }
  		end 
		
		return store_percentage
	end

	def get_planogram_percentage_with_dates(categories,count_of_categories,project_id)
		planogram_percentage_today = []
		planogram_percentage_wtd = []
		planogram_percentage_mtd = []
		all_jcps_mtd = JcpImplementation.joins(promoter_branch_day: {retail_company_branch: :city}).where(cities:{project_id:
		  project_id}, promoter_branch_days:{jcp_date: (Date.today - 30).beginning_of_day ..
				Date.today.end_of_day}).select(:promoter_branch_day_id).distinct
		
		all_jcps_mtd.pluck(:promoter_branch_day_id).each do |jcp|
  		  all_planogram_implementations_mtd = all_jcps_mtd.where(promoter_branch_day_id: jcp)
  		  .sum(:implementation_percentage)
	  	  planogram_percentage_mtd << get_percentage(
	  			all_planogram_implementations_mtd*1.0/100 , count_of_categories) 
	  	end

	  	all_jcps_wtd = all_jcps_mtd.where(promoter_branch_days:{jcp_date: (Date.today-7).beginning_of_day .. 
	  		Date.today.end_of_day}).select(:promoter_branch_day_id).distinct

	  	all_jcps_wtd.pluck(:promoter_branch_day_id).each do |jcp|
	  	  all_planogram_implementations_wtd = all_jcps_wtd.where(promoter_branch_day_id: jcp)
  		  .sum(:implementation_percentage)
	  	  planogram_percentage_wtd << get_percentage(
	  			all_planogram_implementations_wtd*1.0/100 , count_of_categories)
	  	end

	  	all_jcps_today = all_jcps_wtd.where(promoter_branch_days:{jcp_date: Date.today.beginning_of_day ..
	  		Date.today.end_of_day}).select(:promoter_branch_day_id).distinct
	  	all_jcps_today.pluck(:promoter_branch_day_id).each do |jcp|
	  	  all_planogram_implementations_today = all_jcps_today.where(promoter_branch_day_id: jcp)
  		  .sum(:implementation_percentage)
	  	  planogram_percentage_today << get_percentage(
	  			all_planogram_implementations_today*1.0/100 , count_of_categories)
	  	end
		avg_planogram_today = get_percentage(planogram_percentage_today.sum*0.01 , planogram_percentage_today.count)
		avg_percentage_wtd = get_percentage(planogram_percentage_wtd.sum*0.01 , planogram_percentage_wtd.count)
		avg_percentage_mtd = get_percentage(planogram_percentage_mtd.sum*0.01 , planogram_percentage_mtd.count)
  		return {'planogram_percentage_today': avg_planogram_today,'planogram_percentage_wtd': 
  			avg_percentage_wtd,'planogram_percentage_mtd': avg_percentage_mtd}
  		end
  		

  		####################### MSL Chart ##############################

  	def get_MSL_percentage_with_dates(project_id)
  		all_msl_items = ItemsAvailability.joins(promoter_branch_day: [:promoter ,{retail_company_branch: :city}])
  		.where('cities.project_id = ?' ,project_id )
  		.where(promoters: {promoter_role_id: 2})
  		all_msl_items_today = all_msl_items.where(created_at: Date.today.beginning_of_day .. Date.today.end_of_day)
  		available_items_today = all_msl_items_today.where(is_available: 1)
  		msl_percentage_today = get_percentage(available_items_today.count*1.0 , all_msl_items_today.count) 
  		all_msl_items_wtd = all_msl_items.where(created_at: (Date.today - 7).beginning_of_day ..Date.today.end_of_day)
  		available_items_wtd = all_msl_items_wtd.where(is_available: 1)
  		msl_percentage_wtd = get_percentage(available_items_wtd.count*1.0 , all_msl_items_wtd.count)
		all_msl_items_mtd = all_msl_items.where(created_at: (Date.today - 30).beginning_of_day ..Date.today.end_of_day)
  		available_items_mtd = all_msl_items_mtd.where(is_available: 1)
  		msl_percentage_mtd = get_percentage(available_items_mtd.count*1.0 , all_msl_items_mtd.count)
  		return {'msl_percentage_today': msl_percentage_today,'msl_percentage_wtd': msl_percentage_wtd,'msl_percentage_mtd': msl_percentage_mtd}
  		end


	

	def get_citis_vs_msl(project_id,start_date,end_date)
		cities = City.where(project_id: project_id)  # change to current user
		city_percentage = []
		cities.each do |city|
			msl_items = ItemsAvailability.joins(promoter_branch_day: [:retail_company_branch,:promoter])
			.where(retail_company_branches:{city_id:  city.id })
			.where(promoters:{promoter_role_id: 2})
            .where('items_availabilities.created_at >= ? AND items_availabilities.created_at <= ?', 
            	start_date ,end_date)
			available_items = msl_items.where(is_available: 1).count
			percentage = get_percentage(available_items*1.0 , msl_items.count)
	 		city_percentage << {'city': city.city_name , 'percentage': percentage.to_s + '%'}
		end
		return city_percentage	
	end

	def get_chains_vs_msl(project_id,start_date,end_date)
		chains = RetailCompany.where(project_id: project_id) # change to current user
		chain_percentage = []
		chains.each do |chain|
			msl_items = ItemsAvailability.joins(promoter_branch_day: [:promoter,:retail_company_branch])
			.where(retail_company_branches: {retail_company_id: chain.id})
			.where(promoters:{promoter_role_id: 2})
			.where('items_availabilities.created_at >= ? AND items_availabilities.created_at <= ?', 
            	start_date ,end_date)
			available_items = msl_items.where(is_available: 1).count
			percentage = get_percentage(available_items*1.0 , msl_items.count)
			chain_percentage << {'chain': chain.retail_company_name , 'percentage': percentage.to_s + '%'}
		end
		return chain_percentage
	end

	def get_branches_vs_msl(project_id,start_date,end_date)
		branches = RetailCompanyBranch.joins(:retail_company).where('retail_companies.project_id = ?' ,project_id) # change to current user
		branch_percentage = []
		branches.each do |branch|
			msl_items = ItemsAvailability.joins(promoter_branch_day: :promoter)
			.where(promoter_branch_days: {retail_company_branch_id:  branch.id})
			.where(promoters: {promoter_role_id: 2})
			.where('items_availabilities.created_at >= ? AND items_availabilities.created_at <= ?', 
            	start_date ,end_date)
			available_items = msl_items.where(is_available: 1).count
			percentage = get_percentage(available_items*1.0 , msl_items.count)
			branch_percentage << {'branch': branch.branch_name , 'percentage': percentage.to_s + '%'}
		end
		return branch_percentage
	end

	################### Missing jcp ###################################


	def get_missing_visit_by_cities(project_id , start_date , end_date)
		cities_array=Array.new
		cities=City.where(project_id: project_id)
		cities.each do |city|
			all_jcp = PromoterBranchDay.joins(:promoter,:retail_company_branch)
			.where(retail_company_branches: {city_id: city.id} )
			.where(retail_company_branches: {is_deleted: 0} )
       		.where('promoter_branch_days.jcp_date >= ? AND promoter_branch_days.jcp_date <= ?',
       		 start_date ,end_date)
       		.where(promoters: {promoter_role_id: 2})

			checked_in_jcps = PromoterCheckIn.where(promoter_branch_day_id: all_jcp.ids).count
			not_checked_in=all_jcp.count-checked_in_jcps
			cities_array << { 
				'city': city.city_name,
				'percentage': get_percentage( not_checked_in,all_jcp.count ).to_s + '%'
			 }

		end

		cities_array

	end

	def get_missing_visit_by_chain(project_id , start_date , end_date)
		chain_array=Array.new
		chains=RetailCompany.where(project_id: project_id)
		chains.each do |chain|
			all_jcp = PromoterBranchDay.joins(:promoter ,:retail_company_branch)
			.where(retail_company_branches: {retail_company_id: chain.id})
			.where(retail_company_branches: {is_deleted: 0} )
			.where('promoter_branch_days.jcp_date >= ? AND promoter_branch_days.jcp_date <= ?',
       		 start_date ,end_date)
			.where(promoters: {promoter_role_id: 2})
			checked_in_jcps = PromoterCheckIn.where(promoter_branch_day_id: all_jcp.ids).count
			not_checked_in=all_jcp.count-checked_in_jcps
			chain_array << {
				chain: chain.retail_company_name,
				percentage: get_percentage(not_checked_in,all_jcp.count)
				
			}
		end
		chain_array
	end

	def get_missing_visit_by_branch(project_id , start_date , end_date)
		store_array=Array.new
		stores=RetailCompanyBranch.joins(:retail_company)
		.where(retail_companies:{project_id: project_id})
		.where(retail_company_branches: {is_deleted: 0} )

		stores.each do |store|
			all_jcp_in_the_branch = PromoterBranchDay.joins(:promoter).where(retail_company_branch_id: store.id )
			 .where('promoter_branch_days.jcp_date >= ? AND promoter_branch_days.jcp_date <= ?',
       		 start_date ,end_date)
       		 .where(promoters: {promoter_role_id: 2})
			checked_in_jcps = PromoterCheckIn.where(promoter_branch_day_id: all_jcp_in_the_branch.ids).count
			not_checked_in=all_jcp_in_the_branch.count - checked_in_jcps

			percentage = get_percentage(not_checked_in*1.0, all_jcp_in_the_branch.count)
			
			store_array << {
				store: store.branch_name,
				percentage: percentage
			}
		end
		store_array

	end

	def get_percentage(part,total)
		if (total == 0)
			'--'
		else
			(Float((part*1.0)/total)*100).round(2)
		end
	end




end
