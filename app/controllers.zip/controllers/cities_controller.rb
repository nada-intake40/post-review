class CitiesController < ApplicationController
	before_action :authenticate_user!

	def stock_per_city
		render json: BranchDevice.joins(retail_company_branch: [:city,:retail_company])
		.where(retail_companies: {project_id: current_user.project_id})
		.group(:city_name).select("SUM(branch_devices.quantity) AS total_quantity,cities.city_name")

	end

	def index
		render json: City.where(project_id:current_user.project_id)
	end

	def add_city_to_project
		city = City.find_by(city_name: params[:city_name] , project_id: current_user.project_id)
		if city
			render json: {'error': 'Already exists!'} , status: 422
		else
			city = City.new({city_name:params[:city_name],project_id:current_user.project_id})
			if city.save
	    	  	render json: city, status: :created
	    	else
	    		# byebug
	      		render json: city.errors, status: :unprocessable_entity
	   		end
		end
	end

	def delete_city
		city=City.find(params[:city_id])
		city.destroy
	end

end
