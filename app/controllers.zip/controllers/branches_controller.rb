class BranchesController < ApplicationController
	before_action :authenticate_user!
require 'date'


	def user_info
		render json: User.find(:user_id)

	end

	def get_branch_info
		render json: RetailCompanyBranch.find(params[:branch_id])
	end

	def sales_for_each_city
	  cities = City.where(project_id: current_user.project_id)
	  sales_array = []
	  cities.each do |city|
   	    sales = InvoiceDevice.joins(invoice: :retail_company_branch)
		.where({retail_company_branches: {city_id: city.id}})
		sales_array << {'city_name':city.city_name,'volume': sales.sum(:quantity),
			'value': sales.sum("price*quantity")}

	  end
		render json: sales_array
	end

	def get_promoters_in_branch
		render json: Promoter.where(retail_company_branch_id: params[:retail_company_branch_id])

	end

	def promoters_attendence
		branch_conditions = {}
		# retail_conditions = {}
		# city_conditions = {}
	 #    retail_conditions[:id] = params[:retail_id].blank? ?  RetailCompany.where(project_id:current_user.project_id).map(&:id) : params[:retail_id] 
	 #    city_conditions[:id] = params[:city_id].blank? ? City.where(project_id:current_user.project_id).map(&:id) :  params[:city_id]
	    branch_conditions[:id] = params[:branch_id].blank? ? RetailCompanyBranch.joins(:retail_company)
	    .where(retail_companies: {id: current_user.project_id},is_deleted:0).map(&:id) : params[:branch_id]
	    
	    date_range={}

	    if params[:date]
	    	date_range[:created_at]=DateTime.parse(params[:date]).beginning_of_day .. DateTime.parse(params[:date]).end_of_day
	    else
			date_range[:created_at]=Date.today.beginning_of_day .. Date.today.end_of_day	    	
	    end

		check_ins = Promoter.joins(:promoter_check_ins).joins(retail_company_branch: [:retail_company,:city])
		.where(retail_company_branches:branch_conditions,promoter_check_ins:date_range).count
			# promoter_check_ins:date_range).count
		# .where(retail_companies: {project_id: current_user.project_id})
		# .where(retail_company_branches: branch_conditions)
		# .where(cities: city_conditions)
		

		all_promoters_count=Promoter.joins(retail_company_branch: [:retail_company,:city])
		.where(retail_company_branches:branch_conditions).count
		# ,cities:city_conditions)
		# .where(retail_companies: {project_id: current_user.project_id})
		 # .where(retail_companies:retail_conditions)
		
		# byebug
		percentage= (Float(check_ins) / Float(all_promoters_count) * 100.0).round(2)

		render json: {all_promoters_count:all_promoters_count,percentage:percentage,attended:check_ins,absent:all_promoters_count - check_ins}

	end

	def promoters_total_attendence
		check_ins = Promoter.joins(:promoter_check_ins,retail_company_branch: {retail_company: :project})
			.where(projects: {id:current_user.project_id},promoter_check_ins:{created_at:Date.today.beginning_of_day .. Date.today.end_of_day}).count
		# check_ins=PromoterCheckIn.joins(:promoter).where(promoter:{retail_company_branch_id:params[:retail_company_branch_id]},created_at: Date.today.beginning_of_day .. Date.today.end_of_day).count
		all_promoters_count=Promoter
							.joins(retail_company_branch: :retail_company)
							.where(retail_companies: {project_id: current_user.project_id})
							.count
		percentage= (Float(check_ins) / Float(all_promoters_count) * 100.0).round(2)
		render json: {all_promoters_count:all_promoters_count,percentage:percentage,attended:check_ins,absent:all_promoters_count - check_ins}

	end

	def out_of_stock_by_store
		render json: OutOfStock
		.joins(retail_company_branch: :retail_company)
		.where({retail_companies:{project_id:current_user.project_id}})
		.group(:branch_name,"retail_company_branches.branch_name")
		.select("count(out_of_stocks.id) as items_count,retail_company_branches.branch_name")
	end

	def out_of_stock_by_store_devices
		render json: OutOfStock
		.joins(retail_company_branch: :retail_company).joins(device: :item)
		.where(retail_companies:{project_id:current_user.project_id})
		.select("out_of_stocks.id,retail_company_branches.branch_name,devices.device_name,items.item_name")
	end

	def total_out_of_stock
		render json: {
			out_of_stock_by_product: OutOfStock
			.joins(retail_company_branch: :retail_company)
			.where({retail_companies:{project_id:current_user.project_id}})
			.count,
			out_of_stock_by_store: OutOfStock			
			.joins(retail_company_branch: :retail_company)
			.where({retail_companies:{project_id:current_user.project_id}})
			.distinct.pluck(:device_id).count
		}
	end

	def stock_by_item_name
		render json: BranchDevice.joins(device: :item).joins(retail_company_branch: :retail_company)
		.where({retail_companies:{project_id:current_user.project_id}})
		.group(:item_name)
		.pluck("SUM(branch_devices.quantity) AS total_quantity,items.item_name")
	end

	def get_feedbacks
	  project_id = current_user.project_id
      city_id = params[:city_id].blank? ? City.where(project_id: project_id).pluck(:id) : params[:city_id]
      retail_id = params[:retail_id].blank? ? RetailCompany.where(project_id: project_id).pluck(:id) : params[:retail_id]
      branch_id = params[:branch_id].blank? ? RetailCompanyBranch.joins(:retail_company)
      .where(retail_companies: {project_id: project_id}).pluck(:id) : params[:branch_id]
      start_date = params[:start_date].blank? ? (Date.today-30).beginning_of_day 
      : Date.parse(params[:start_date]).beginning_of_day
      end_date = params[:end_date].blank? ? Date.today.end_of_day 
      : Date.parse(params[:end_date]).end_of_day
      

		render json: Feedback.joins(:promoter,retail_company_branch: [:city , :retail_company])
		.where(retail_company_branches:{city_id:city_id,retail_company_id:retail_id},retail_company_branch_id:branch_id,
			created_at: start_date.. end_date)
		.select("promoters.id,promoters.username ,retail_company_branches.branch_name,cities.city_name,feedbacks.feedback_body,feedbacks.created_at,
							feedbacks.updated_at") , methods: [:decoded_emojis]

		

	end

	def competitor_by_quantity
		render json: Competitor
		.joins(:brand)
		.where(brands: {project_id:current_user.project_id})
		.group(:brand_name)
		.select("brands.brand_name,SUM(competitors.quantity) as quantity")
	end

	def competitor_by_price

		render json: Competitor.joins(:brand)
		.where(brands: {project_id:current_user.project_id})
		.group(:brand_name).select("brands.brand_name,SUM(competitors.quantity * competitors.price) as price ")

	end

	def competitor_by_quantity_in_branch
		retail_conditions = {}
		city_conditions = {}
	    retail_conditions[:id] = params[:retail_id].blank? ?  RetailCompany.where(project_id:current_user.project_id).map(&:id) : params[:retail_id] 
	    city_conditions[:id] = params[:city_id].blank? ? City.where(project_id:current_user.project_id).map(&:id) :  params[:city_id]
	    
		render json: Competitor.joins(retail_company_branch: [:retail_company,:city])
		.where(retail_companies: {project_id:current_user.project_id})
		.where(retail_companies: retail_conditions,cities: city_conditions)
		.group(:branch_name).select("retail_company_branches.branch_name,SUM(competitors.quantity) as quantity")
	end

	def competitor_by_pcompetitor_by_price_in_branchrice_in_branch
		retail_conditions = {}
		city_conditions = {}
	    retail_conditions[:id] = params[:retail_id].blank? ?  RetailCompany.where(project_id:current_user.project_id).map(&:id) : params[:retail_id] 
	    city_conditions[:id] = params[:city_id].blank? ? City.where(project_id:current_user.project_id).map(&:id) :  params[:city_id]

		render json: Competitor.joins(retail_company_branch: [:retail_company,:city])
		.where(retail_companies: {project_id:current_user.project_id})
		.where(retail_companies: retail_conditions,cities: city_conditions)
		.group(:branch_name)
		.select("retail_company_branches.branch_name,SUM(competitors.quantity * competitors.price) as price ")

	end

	def add_branch
		branch = RetailCompanyBranch.where(retail_company_id:params[:retail_company_id],city_id:params[:city_id],store_class_id:params[:class_id],is_deleted:0)
		.where("replace(branch_name, ' ', '') = replace(?, ' ', '')",params[:branch_name])
		if branch.any? 
		  render json: {'Error': 'Already exists!'} ,status: 422
		else
		  branch=RetailCompanyBranch.new({branch_name:params[:branch_name],retail_company_id:params[:retail_company_id],city_id:params[:city_id],store_class_id:params[:class_id],is_deleted:0,center_lat:params[:center_lat],center_lng:params[:center_lng]})
		  branch_boundries=Array.new
		  branch_categories=Array.new
		  params[:branch_boudries].each { |boudry|
			branch_boundries << BranchBoundry.new({latitude:boudry["latitude"],longitude:boudry["longitude"]}) 
		  }
		  branch.branch_boundries = branch_boundries
		

		if branch.save
			render json: branch,status: :created
		else
			render json: branch.errors ,status: :unprocessable_entity
		end
	end
	end

	def edit_boundries
		branch=RetailCompanyBranch.find(params[:branch_id])
		branch_boundries=Array.new
		
		params[:branch_boundries].each { |boudry|
			branch_boundries << BranchBoundry.new({latitude:boudry["latitude"],longitude:boudry["longitude"]}) 
		}
		branch.branch_boundries = branch_boundries
		branch.retail_company_id = params[:retail_id]
		branch.branch_name = params[:branch_name]
		branch.store_class_id = params[:class_id]
		branch.city_id = params[:city_id]

		if branch.save
			render json: branch
		else
			render json: branch.errors ,status: :unprocessable_entity
		end

	end


	def get_boundries
		branch=RetailCompanyBranch.find(params[:branch_id])
		render json:branch.branch_boundries
	end

	def get_branches
		retail_conditions = {}
		city_conditions = {}
		class_conditions = {}
	    retail_conditions[:id] = params[:retail_id].blank? ?  RetailCompany.where(project_id:
	    	current_user.project_id).map(&:id) : params[:retail_id] 
	    city_conditions[:id] = params[:city_id].blank? ? City.where(project_id:
	    	current_user.project_id).map(&:id) :  params[:city_id]
	    class_conditions[:id] = params[:class_id].blank? ? StoreClass.all.map(&:id) 
	    :  params[:class_id]
	    
		render json: RetailCompanyBranch.joins(:retail_company,:city,
			:store_class).where(retail_companies:retail_conditions,
			cities:city_conditions,store_classes:class_conditions,is_deleted: 0).
			select(:id,:branch_name,:store_class_id,:retail_company_id,
				:city_id).order(:branch_name) ,
			 methods: [:get_class_name,:get_retail_name,:get_city_name]

	end

	def add_promoter

		promoter=Promoter.new({username:params["username"],password:params["password"],promoter_role_id:params["role_id"],
			project_id:current_user.project_id,mobile:params["mobile"],name:params["name"]})
		
		if promoter.save


			if(params[:image] != "")

				photo = params[:image]


		        img_split=photo.split(',')
		        ext_split = img_split[0].split('/')
		        ext  = ext_split[1].split(";")

		        promoter_image = "user_img.#{ext[0]}"
		        photoEncode = img_split[1]


		        dir = File.dirname("public/promoters/#{promoter.id}/"+promoter_image)
		        FileUtils.mkdir_p(dir) unless File.directory?(dir)
		    
		        decode_photo= Base64.decode64(photoEncode)
		        File.open("public/promoters/#{promoter.id}/"+promoter_image, 'wb') { |f| f.write(decode_photo) }

		        promoter_update = Promoter.where(:id =>promoter.id).limit(1).
		        update_all(:image=>promoter_image)
			end
    	

			render json: promoter,status: :created
		else
			render json: promoter.errors ,status: :unprocessable_entity
		end
	end

	def get_promoters_state
		# all_promoters=Array.new
		# all_promoters = all_promoters + Promoter.joins([:promoter_check_ins])
		# 		.select("promoters.*,promoter_check_ins.check_in_state_id")
		# 		.where(promoter_role_id:1,promoter_check_ins: {created_at: Date.today.beginning_of_day .. Date.today.end_of_day})
		# all_promoters =  all_promoters + Promoter.select("promoters.*")
		# 		.where.not(promoters: {promoter_role_id:1,id: all_promoters.map(&:id) }	)

		# render json:all_promoters
		render json: Promoter.where(promoter_role_id: 1,project_id:current_user.project_id ).order(id: :desc), methods: [:get_image , :get_number_of_branches_visited]
		
	end

	def get_merchs
		render json: Promoter.where(promoter_role_id: 2,project_id:current_user.project_id).order(id: :desc) , methods: :get_number_of_branches_visited
		
	end

	def get_promoter_for_each_city
		render json: RetailCompanyBranch.joins([:city, promoter_branch_days: :promoter])
		.where(cities: {project_id:current_user.project_id} ,is_deleted:0)
		.select("city_name,SUM(promoters.id) as total_no").group(:city_name)
	end

	def voc_per_branch
		render json: Feedback.joins(retail_company_branch: :retail_company)
		.where(retail_companies:{project_id: current_user.project_id})
		.select("COUNT(feedbacks.id) as voc_count,branch_name").group(:branch_name)
	end

	def promoter_came_out
		check_in=PromoterCheckIn.find_by({promoter_id:params[:promoter_id],created_at:Date.today.beginning_of_day .. Date.today.end_of_day})
		
		check_in.check_in_state_id = 2
		if check_in.save
			render json: check_in
		else
			render json: check_in.errors ,status: :unprocessable_entity
		end

	end

	def all_branches
		render json: RetailCompanyBranch.joins(:retail_company).where(retail_companies: { project_id: current_user.project_id } ,is_deleted:0)
	end

	def delete_branch
		branch=RetailCompanyBranch.find(params[:branch_id])
		branch.is_deleted = 1
		branch.save
		render json: {message: "success"}
	end
end
