class CategoriesController < ApplicationController
  require "base64"
  include PromoterHelper
    before_action :authenticate_user!

  before_action :set_category, only: [:show, :update, :destroy]

  def list_planograms
    planograms = Planogram.where(category_id: params[:category_id])
    render json: planograms
  end


  # GET /categories
  def index
    @categories = Category.where(project_id:current_user.project_id)

    render json: @categories
  end

  # GET /categories/1
  def show
    render json: @category , methods: [:get_planograms]
  end

  # POST /categories
  def create
    @category = Category.new(category_params)
    @category.project_id = current_user.project_id
    if @category.save
        img_split = params[:image_string].split(',')
        ext_split = img_split[0].split('/')
        ext = ext_split[1].split(";")
        image_path = get_category_dir(@category.id , ext[0])
        image_string = img_split[1]
        save_category(image_string,image_path)
        @category.image = image_path
        @category.save
        if params[:planogram_images] != []
                params[:planogram_images].each { |image|
                      img_split = image.split(',')
                      ext_split = img_split[0].split('/')
                      ext = ext_split[1].split(";")
                      image_path = get_planogram_image_dir(@category.id,ext[0])
                      image_string = img_split[1]
                      save_planogram(image_string,image_path)

                      planogram = Planogram.new(planogram_image:image_path , category_id:@category.id)
                      planogram.save
                    }
        end
          render json: @category, status: :created, location: @category
    else
      render json: @category.errors, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /categories/1
  def update
    if @category.update(category_params)
      render json: @category
    else
      render json: @category.errors, status: :unprocessable_entity
    end
  end

  # DELETE /categories/1
  def destroy
    items = Item.where(category_id: @category.id).pluck(:id)
    Device.where(item_id: items).destroy_all
    ItemsAvailability.where(item_id: items).destroy_all
    Item.where(category_id: @category.id).destroy_all
    JcpImplementation.where(category_id: @category.id).destroy_all
    @category.destroy
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_category
      @category = Category.find(params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def category_params
      params.require(:category).permit(:category_name)
    end
end

def save_category(image_string,image_path)
      

      File.open("public/#{image_path}", 'wb') do |f|
        f.write(Base64.decode64(image_string))
      end
    end

def save_planogram(image_string,image_path)
      

      File.open("public/#{image_path}", 'wb') do |f|
        f.write(Base64.decode64(image_string))
      end
end