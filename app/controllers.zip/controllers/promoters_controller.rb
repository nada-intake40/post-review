class PromotersController < ApplicationController
  require "base64"
  include PromoterHelper, MapHelper , Auth
  
  before_action :set_promoter, only: [:show, :update, :destroy]
  before_action :auth_promoter_with_branch , except: [:test,:view_promoter_profile,:login,:list_gcp,:updateLocation,:getPromotersCheckInsArray,:list_assigned_branches]
  before_action :auth_promoter , only: [:view_promoter_profile,:list_assigned_branches,:check_in,:list_gcp]

  def get_customer_engagement
    customer_engagement = CustomerEngagement.where(promoter_branch_day_id: params[:jcp_id])
    render json: customer_engagement
  end

  def get_samples
    render json: Sample.where(promoter_branch_day_id: params[:jcp_id])
  end

  def create_sample
    sample = Sample.new(total_samples: params[:distributed_samples].to_i+params[:remaining_samples].to_i,distributed_samples: 
      params[:distributed_samples], promoter_branch_day_id: params[:jcp_id])
    if sample.save
      render json: sample
    else
      render json: sample.errors , status: 422
    end

  end

  def create_customer_engagement
    customer_engagement = CustomerEngagement.new(customer_name: params[:customer_name],phone: params[:phone],email:
     params[:email],promoter_branch_day_id: params[:jcp_id])
    if customer_engagement.save
      render json: customer_engagement 
    else
      render json: customer_engagement.errors , status: 422
    end
  end


  def view_promoter_profile
  	render json: @promoter 

  end

  def submit_implementation_percentage
    if params[:reason_id] && params[:reason_id] != ""
      reason_id = params[:reason_id]
    else
      reason_id = nil
    end
    jcp_implementation = JcpImplementation.find_by(promoter_branch_day_id:params[:jcp_id],category_id:params[:category_id])
    if jcp_implementation
      JcpImplementation.where(promoter_branch_day_id:params[:jcp_id],category_id:params[:category_id]).update_all(reason_id:reason_id,implementation_percentage:params[:implementation_percentage],share_of_shelve_percentage:params[:share_of_shelve_percentage])
    else
        jcp_implementation = JcpImplementation.new(promoter_branch_day_id:params[:jcp_id],category_id:params[:category_id],reason_id:reason_id,implementation_percentage:params[:implementation_percentage],share_of_shelve_percentage:params[:share_of_shelve_percentage])
        jcp_implementation.save 
    end
            if params[:planogram_before_images] != []
              upload_before_images(params[:jcp_id],params[:category_id],jcp_implementation.id,params[:planogram_before_images])   
            end

            if params[:planogram_after_images] != []
              upload_after_images(params[:jcp_id],params[:category_id],jcp_implementation.id,params[:planogram_after_images])
            end
        render json: jcp_implementation , status: 200
  end

  def upload_power_of_wings_photos
      if params[:power_of_wings_photos] != []
          params[:power_of_wings_photos].each do |image| 
              power_of_wings_photo_path = get_power_of_wings_photo_dir(params[:jcp_id])
              PowerOfWingsPhoto.create(promoter_branch_day_id:params[:jcp_id],image:power_of_wings_photo_path)         
              save_power_of_wings_images(image , power_of_wings_photo_path)
          end
      
          render json: {'message': 'OK!'} , status: 200
      else
          render json: {'message': 'No images uploaded!'} , status: 200
      end
  end

  def submitMSL
    items_availability = ItemsAvailability.where(promoter_branch_day_id: params[:jcp_id])
    if items_availability.any? 
      params[:items].each { |item|
        items_availability.where(item_id:item['item_id']).update(is_available: item['is_available'])
      }
    else
      params[:items].each { |item|
        # print('oooooooooooooooooo',item['item_id'])
        item = ItemsAvailability.new(item_id:item['item_id'],is_available:item['is_available'],promoter_branch_day_id:params[:jcp_id])
      item.save
      }
      end
      render json: {'msg': 'OK'}
    
  end

  def getPromotersCheckInsArray
    promoters_array = PromoterBranchDay.left_outer_joins(:promoter , :promoter_check_in).where(retail_company_branch_id: params[:branch_id],promoters:{promoter_role_id: 1},jcp_date: Date.today)
    .select('promoter_check_ins.latitude','promoter_check_ins.longitude','promoters.id,promoters.username','promoter_check_ins.check_in_state_id')
    render json: promoters_array
  end

  def updateLocation
#    ActionCable.server.broadcast( "UpdateLocation_#{@promoter.retail_company_branch_id}", { lat: params['lat'], long: params['lng'] , promoter_id: @promoter.id})

    ActionCable.server.broadcast( 'UpdateLocation', { lat: params['lat'], long: params['lng'] , promoter_id: params['promoter_id']})
  end
  # GET /promoters
  def index
    @promoters = Promoter.all

    render json: @promoters
  end

  # GET /promoters/1
  def show
    promoter = Promoter.where(id:params[:id])  
    if promoter
        render json: promoter , status: 200
    else
        render json: promoter.errors ,status: 422
    end
  end

  # POST /promoters
  def create
    @promoter = Promoter.new(promoter_params)

    if @promoter.save
      render json: @promoter, status: :created, location: @promoter
    else
      render json: @promoter.errors, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /promoters/1
  def update
    if @promoter.update(promoter_params)
      render json: @promoter
    else
      render json: @promoter.errors, status: :unprocessable_entity
    end
  end

  # DELETE /promoters/1
  def destroy
    @promoter.destroy
  end

  def login 
  	username=params[:username]
    password=params[:password]
    @promoter=Promoter.find_by_username(username)

    if !@promoter
      render json:{error:"Wrong Username"},status: 401
      return
    end

    if @promoter.password != password
      render json: {error:"Wrong Password"},status: 401
      return
    end

    tokenObj=generate_user_token(@promoter.id)
    response.headers["token"] = tokenObj.token
    response.headers["promoter_id"] = @promoter.id
    # lo
    render json:@promoter, :except => [:password]




  end

  def check_in
    
    latitude=params[:latitude]
    longitude=params[:longitude]
    image_string=params[:image_string]
    
    
    if ! is_promoter_inside(latitude,longitude,@branch.id)
      render json: {error:"Wrong Location"},status: 402
      return
    end

    # if ! get_working_hours_range(@promoter.retail_company_branch.retail_company.project_id)
    #   render json: {error:"Out Of Working Hours"},status: :unauthorized
    # end

    

    image_path = get_selfie_dir(@branch.retail_company.project_id,
        @branch.id)

    save_selfie(image_string,image_path)
    check_in = PromoterCheckIn.find_by(promoter_id:@promoter.id,created_at: Date.today.beginning_of_day .. Date.today.end_of_day , promoter_branch_day_id:params[:jcp_id])

    if ! check_in

      check_in=PromoterCheckIn.new({promoter_id:@promoter.id,latitude:latitude,
        longitude:longitude,check_in_state_id:1,image_path:image_path,date:Date.today.strftime('%Y-%m-%d'),
        expiration_time:Date.today.end_of_day ,promoter_branch_day_id:params[:jcp_id]})
      if ! check_in.save
        render json: check_in.errors , status: 422
        return
        end

    end
      render json:@promoter, :except => [:password]

  end


   def test_branch_auth
    puts "asdasd"
   end
  def list_assigned_branches
    render json: [1,2,3,4]
  end  

  

  def check_out

    latitude=params[:latitude]
    longitude=params[:longitude]

    if ! is_promoter_inside(latitude,longitude,@branch.id)
      render json: {error:"Wrong Location"},status: 402
      return
    end

    promoter_checkout = PromoterBranchDay.where(:id => params[:jcp_id]).limit(1).update_all(is_visited: 1)
    checkout_time = PromoterCheckIn.where(promoter_branch_day_id: params[:jcp_id] , promoter_id:@promoter.id ).update(check_out_time:DateTime.now)
    if(promoter_checkout && checkout_time)
      render json: {message: "checkout success"}, status: "200"
    end
 
  end

  def create_invoice
    invoice_devices_params=params['invoice_devices']
    branch_id=@branch.id
    invoice=Invoice.new({retail_company_branch_id:branch_id})
    invoice.invoice_devices=get_invoice_devices(invoice_devices_params)
    if invoice.save
       render json: invoice, status: :created
    else
       render json: invoice.errors, status: :unprocessable_entity
    end

  end


  def edit_invoice
    invoice=Invoice.find(params["invoice_id"])
    invoice.invoice_devices=get_invoice_devices(params["invoice_devices"])
  
    if invoice.save
      render json: invoice, status: :created
    else
        render json: invoice.errors, status: :unprocessable_entity
    end  
  end


  def get_brands
    project_id=@branch.retail_company.project_id

    brands = Brand.where(project_id:project_id)
    render json: brands

  end

  def get_brand_categories
    project_id=@branch.retail_company.project_id

    categories = Category.where(project_id:project_id)
    render json: categories
  end

  def get_category_devices
    devices = Device.where(brand_id:params[:brand_id],category_id:params[:category_id])
    render json: devices
  end

  def get_item_devices

    devices = Device.joins(:item).where(item_id:params[:item_id]).where("items.brand_id = '#{params['brand_id']}' AND items.category_id = '#{params['category_id']}'")
    render json: devices
  end

  def get_items
    items = Item.where(brand_id:params[:brand_id],category_id:params[:category_id])
    render json: items
  end

  def get_devices_in_project
    project_id=@branch.retail_company.project_id
    brands=Brand.where(project_id:project_id)
    render json: brands.to_json(include: {categories: { include: {items: { include: :devices}} } })

  end



  def view_promoter_invoices
    invoices=@branch.invoices.where(get_project_day_range(@branch.retail_company.project_id))
    render json: invoices, methods: [:invoice_devices_names ]
  end

  def add_stock
    device_id=params["device_id"]
    quantity=params["quantity"]
    branch_id=@branch.id
    branch_device=BranchDevice.find_by({device_id:device_id,retail_company_branch_id:branch_id})
    if branch_device
      branch_device.quantity=quantity
      branch_device.created_at=DateTime.now
    else
      branch_device=BranchDevice.new({device_id:device_id,retail_company_branch_id:branch_id,quantity:quantity})
    end

    if branch_device.save
      render json: branch_device, status: :created
   else
      render json: branch_device.errors, status: :unprocessable_entity
   end

  end

  def view_stock
    
    category_conditions={}
    items_conditions={}
    brand_conditions={}
    project_id=@branch.retail_company.project_id

    category_conditions[:id] = params[:category_id].blank? ?  Category.where(project_id:project_id).map(&:id) : params[:category_id] 
    items_conditions[:id] = params[:item_id].blank? ?  Item.joins(:brand).where(brands: {project_id:project_id} ).map(&:id) : params[:item_id] 
    brand_conditions[:id] = params[:brand_id].blank? ?  Brand.where( project_id:project_id ).map(&:id) : params[:brand_id] 
    
    branch_devices=BranchDevice.joins(device: { item: [:brand ,:category]  })
    .where(retail_company_branch_id:@branch.id)
    .where(items:items_conditions,brands:brand_conditions,categories:category_conditions)
    .where(get_project_day_range(@branch.retail_company.project_id))
    .select("branch_devices.id, devices.device_name, branch_devices.price ,branch_devices.quantity ,items.item_name,categories.category_name,brands.brand_name")
    # 

    render json:branch_devices
  end

  def delete_stock
    device=BranchDevice.find(params["branch_device_id"])
    device.destroy
    render json: {}
  end

  def add_out_of_stock
    device_id=params["device_id"]
    branch_id=@branch.id

    out_of_stock=OutOfStock.find_by({device_id:device_id,retail_company_branch_id:branch_id})
    if out_of_stock
      out_of_stock.created_at=DateTime.now
      out_of_stock.save
      render json: {},status: :created

    else
      out_of_stock=OutOfStock.new({device_id:device_id,retail_company_branch_id:branch_id})
      if out_of_stock.save
        render json: out_of_stock, status: :created
      else
        render json: out_of_stock.errors, status: :unprocessable_entity
      end
    end
  end

  def list_out_of_stock
    category_conditions={}
    items_conditions={}
    brand_conditions={}
    project_id=@branch.retail_company.project_id


    category_conditions[:id] = params[:category_id].blank? ?  Category.where(project_id:project_id).map(&:id) : params[:category_id] 
    items_conditions[:id] = params[:item_id].blank? ?  Item.joins(:brand).where(brands: {project_id:project_id} ).map(&:id) : params[:item_id] 
    brand_conditions[:id] = params[:brand_id].blank? ?  Brand.where( project_id:project_id ).map(&:id) : params[:brand_id] 

    out_of_stock_items=OutOfStock.joins(device: {item: [:category,:brand] } )    # 
    .where({retail_company_branch_id:@branch.id})
    .where(items:items_conditions,brands:brand_conditions,categories:category_conditions)
    .where(get_project_day_range(project_id))
    .select("out_of_stocks.id, items.item_name,brands.brand_name,categories.category_name,devices.device_name")
    render json: out_of_stock_items
  end

  def delete_out_of_stock
    out_of_stock=OutOfStock.find(params["out_of_stock_id"])
    out_of_stock.destroy
    render json:{}
  end

  def list_brands
    project_id=@branch.retail_company.project_id
    render json: Brand.where(project_id: project_id)
  end

  def send_brand_suggestion

  end

  def add_feedback
    feedback_body=params["feedback_body"]
    feedback=Feedback.new({feedback_body:Rumoji.encode(feedback_body), retail_company_branch_id:@branch.id,promoter_id:@promoter.id})

    if feedback.save
      render json: feedback, status: :created
    else
        render json: feedback.errors, status: :unprocessable_entity
    end
  end

  def edit_feedback
    feedback=Feedback.find(params["feedback_id"])
    feedback.feedback_body=params["feedback_body"]
    if feedback.save
      render json: feedback, status: :created
    else
        render json: feedback.errors, status: :unprocessable_entity
    end
  end

  def delete_feedback
    feedback=Feedback.find(params["feedback_id"])
    feedback.destroy
    render json: {}
  end

  def list_feedback
    feedbacks=Feedback.joins(:promoter).where(retail_company_branch_id: @branch.id)
              .select("feedbacks.*,promoters.username")
              .where( get_project_day_range(@branch.retail_company.project_id) )
    render json: feedbacks, methods: [:from_time ]
  end

  def upload_gallary
    branch=RetailCompanyBranch.find(@branch.id)
    branch_images=Array.new
    base64_images=params["base64_images_array"]
    base64_images.each do |base64_image|
      image_path=get_gallary_image_dir(@branch.retail_company.project_id,
        @branch.id)

      branch_images << BranchImage.new({
        date:Date.today.strftime('%Y-%m-%d'),
        image_path:image_path,
        promoter_id: @promoter.id
      })
      save_image_gallary(base64_image,image_path)
    end
    branch.branch_images << branch_images
    branch.save
    render json: branch
  end

  def view_invoice_details
    invoice=Invoice.find(params["invoice_id"])
    render json: invoice, methods: [:invoice_devices_names ]
  end

  def delete_invoice
    invoice=Invoice.find(params["invoice_id"])
    invoice.destroy
    render json: {}
  end

  def add_competitor
    competitor=Competitor.new({brand_id:params["brand_id"],item_name:params["item_name"],
      price:params["price"],quantity:params["quantity"],retail_company_branch_id:@branch.id})
    if competitor.save
      render json: competitor, status: :created
    else
        render json: competitor.errors, status: :unprocessable_entity
    end
  end

  def list_competitors
    render json: Competitor.joins(:brand).where({retail_company_branch_id:@branch.id})
    .where(get_project_day_range(@branch.retail_company.project_id))
    .select("competitors.id,competitors.item_name,brands.brand_name,competitors.price,competitors.quantity")
  end

  def delete_competitor
    competitor=Competitor.find(params["competitor_id"])
    competitor.destroy
    render json:{}
  end

 def list_categories
 	    project_id=@branch.retail_company.project_id

    categories = Planogram.joins(:category)
    .where(categories:{project_id: project_id})
    .select('planograms.category_id as id , categories.category_name').distinct
    render json: categories, status: "200"
 end

  def list_gcp
    all_jcp = PromoterBranchDay.joins(:retail_company_branch,:promoter).where(promoter_id: @promoter.id,jcp_date:Date.today,retail_company_branches:{is_deleted: 0}).order("store_class_id")
    render json: all_jcp, methods: [:get_class_name ,:get_branch_name,:get_city_name,:get_retail_name,:get_boundries]


  end

  def getListOfHighPeriorityItems
    project_id=@branch.retail_company.project_id
      items = Item.joins(brand: :project)
      .where(periority:true)
      .where(projects:{id:project_id})
      render json: items 
  end

   def list_planograms
    planograms = Planogram.where(category_id: params[:category_id])
    render json: planograms
  end

  def create_stock

    device_id=params["device_id"]
    quantity=params["quantity"]
    item_price=params["item_price"]
    expiration_date = params["expiration_date"]
    is_expired = params['is_expired']
    promoter_branch_day_id = params["jcp_id"]

    branch_id=@branch.id
    # branch_stock=BranchStock.find_by({device_id:device_id,retail_company_branch_id:branch_id})
    # if branch_stock
    #   branch_stock.quantity=quantity
    #   branch_stock.item_price=item_price
    #   branch_stock.expiration_date = expiration_date
    #   branch_stock.is_expired = is_expired
    #   branch_stock.created_at=DateTime.now
    # else
      branch_stock=BranchStock.new({promoter_branch_day_id:promoter_branch_day_id,device_id:device_id,retail_company_branch_id:branch_id,quantity:quantity,item_price:item_price,
        expiration_date:expiration_date,is_expired:is_expired})
    # end

    if branch_stock.save
      render json: branch_stock, status: :created
   else
      render json: branch_stock.errors, status: :unprocessable_entity
   end


  end

  private
  	

    def get_invoice_devices(invoice_devices_params)
      invoice_devices=Array.new

      invoice_devices_params.each do |item_param|
        invoice_devices << InvoiceDevice.new({device_id:item_param["device_id"],price:item_param["price"],quantity:item_param["quantity"]})
        
      end
      return invoice_devices
    end

    def auth_promoter_with_branch
      if ( request.headers["HTTP_PROMOTER_ID"].nil? || request.headers["HTTP_TOKEN"].nil? || request.headers["HTTP_BRANCH_ID"].nil? || request.headers["HTTP_PROMOTER_ID"].empty? || request.headers["HTTP_TOKEN"].empty? || request.headers["HTTP_BRANCH_ID"].empty? )
        
          render json: { error: "promoter not authenticated 2" },status: :unauthorized   
          return
      end

      
      promoter_token=PromoterToken.where(promoter_id:request.headers["HTTP_PROMOTER_ID"],token:request.headers["HTTP_TOKEN"])

        if( promoter_token.empty?  || !valid_token(promoter_token[0].token) )
          render json: { error: "Session Expired" },status: 406
          return
        end

      @promoter=Promoter.find(request.headers["HTTP_PROMOTER_ID"])
      @branch=RetailCompanyBranch.find(request.headers["HTTP_BRANCH_ID"])
    end

    def auth_promoter
      promoter_token=PromoterToken.where(promoter_id:request.headers["HTTP_PROMOTER_ID"],token:request.headers["HTTP_TOKEN"])
      if(promoter_token==[])
        render json: { error: "promoter not authenticated 1" },status: :unauthorized
      else
	      @promoter=Promoter.find(request.headers["HTTP_PROMOTER_ID"])


       	# @promoter=Promoter.find(request.headers["HTTP_PROMOTER_ID"])
        # @branch=RetailCompanyBranch.find(request.headers["BRANCH_ID"])

      	if( !promoter_token[0] || !valid_token(promoter_token[0].token) )
      		render json: { error: "Session Expired" },status: 406
      		return
        end
       return true
      end
    end


    def valid_token(token)
    	## should be removed
    	# return true
    	promoter_token=PromoterToken.find_by_token(token)
    	# date_time_string="#{Date.current.today.strftime("%Y-%m-%d")} #{project.shift_end_in.strftime("%H:%M:%S")}"

      if(promoter_token.expiration_time != nil)
      	
        if(promoter_token.expiration_time > DateTime.now )
      		return true
      	else
      		return false
      	end
        
      else
        return false
      end

    end

    def add_expiration_time(project_id)
	    project=Project.find(project_id)
    	date_time_string="#{Date.current.tomorrow.strftime("%Y-%m-%d")} #{project.shift_end_in.strftime("%H:%M:%S")}"
    	DateTime.parse(date_time_string) + 6.hours
    end

    # Use callbacks to share common setup or constraints between actions.
    def set_promoter
      @promoter = Promoter.find(params[:id])
    end

    def save_selfie(image_string,image_path)
      

      File.open("public/#{image_path}", 'wb') do |f|
        f.write(Base64.decode64(image_string))
      end
    end

    def save_image_gallary(image_string,image_path)
      File.open("public/#{image_path}", 'wb') do |f|
        f.write(Base64.decode64(image_string))
      end
    end

    def save_planogram_before_images(image_string,image_path)
      File.open("public/#{image_path}", 'wb') do |f|
        f.write(Base64.decode64(image_string))
      end
    end

    def save_planogram_after_images(image_string,image_path)
      File.open("public/#{image_path}", 'wb') do |f|
        f.write(Base64.decode64(image_string))
      end
    end

    def save_power_of_wings_images(image_string,image_path)
      File.open("public/#{image_path}", 'wb') do |f|
        f.write(Base64.decode64(image_string))
      end
    end

    # Only allow a trusted parameter "white list" through.
    def promoter_params
      params.require(:promoter).permit(:username, :password, :retail_company_branch_id)
    end

    def upload_before_images(jcp_id,category_id,jcp_implementation_id , images_array)
              planogram_before_images = images_array
              planogram_before_images.each do |image|
                  before_image_path = get_planogram_before_image_dir(jcp_id,category_id)
                  PlanogramBeforeImage.create({
                  jcp_implementation_id: jcp_implementation_id,
                  image_before:before_image_path,
                })
                save_planogram_before_images(image,before_image_path)
              end
    end

    def upload_after_images(jcp_id,category_id,jcp_implementation_id , images_array)
              planogram_after_images = images_array
              planogram_after_images.each do |image|
                  after_image_path = get_planogram_after_image_dir(jcp_id,category_id)
                  PlanogramAfterImage.create({
                  jcp_implementation_id: jcp_implementation_id,
                  image_after:after_image_path,
                })
                save_planogram_after_images(image,after_image_path)
              end
    end
end
