class CustomController < ApplicationController
	require 'roo'
	@d1=Date.parse("2020-2-12")
	@d2=Date.parse("2020-3-2")
	@project_id=7
	
	def update_promoter(promoter_id)
		jcp_ids=get_jcps_ids(promoter_id)
		make_jcps_visited(jcp_ids)
		check_ins_ids=get_check_ins_by_jcps(jcp_ids)
		update_check_ins(check_ins_ids)
		
	end

	def insert_jcp_implementation
		jcp_ids = PromoterBranchDay.where(promoter_id:params[:promoter_ids],is_visited:1).where('promoter_branch_days.jcp_date >= "2020-03-01" and promoter_branch_days.jcp_date <= "2020-03-31"').pluck(:id)
		msl_nahdy = JcpImplementation.where(promoter_branch_day_id: 1249)
		msl_united = JcpImplementation.where(promoter_branch_day_id: 449)
		msl_dawaa = JcpImplementation.where(promoter_branch_day_id: 1252)
		categories = Planogram.joins(:category)
  		.where(categories: {project_id: 7})
  		.select(:category_id).distinct.pluck(:category_id)
		jcp_ids.each do |jcp_id| 
			msl_branch = JcpImplementation.where(promoter_branch_day_id: jcp_id)
				retail = PromoterBranchDay.joins(retail_company_branch: :retail_company).where(id: jcp_id).pluck('retail_companies.retail_company_name')
				jcp = PromoterBranchDay.find_by_id(jcp_id)

			if msl_branch.blank?
				# if retail[0] == 'NAHDI'
				# 	categories_in_nahdi = msl_nahdy.pluck(:category_id)
				# 	intersection_categories = categories & categories_in_nahdi
				# 	missing_categories = categories - categories_in_nahdi
				# msl_nahdy.map{|item|
				# 	if  intersection_categories.include?(item.category_id)
				# 		JcpImplementation.create(category_id: item.category_id,implementation_percentage:item.implementation_percentage,
				# 			reason_id: item.reason_id,share_of_shelve_percentage:item.share_of_shelve_percentage,
				# 			created_at:Time.zone.at(jcp.jcp_date.to_time).to_datetime , updated_at:Time.zone.at(jcp.jcp_date.to_time).to_datetime,promoter_branch_day_id:jcp_id)
				#     end
				# }
				# 	missing_categories.map { |category_id|
				# 	   JcpImplementation.create(category_id: category_id,implementation_percentage:100,
				# 			reason_id: nil,share_of_shelve_percentage:100,
				# 			created_at:Time.zone.at(jcp.jcp_date.to_time).to_datetime , updated_at:Time.zone.at(jcp.jcp_date.to_time).to_datetime,promoter_branch_day_id:jcp_id)
				#   }

				# }
			# 	elsif retail[0] == 'UNITED'
			# 		categories_in_united = msl_united.pluck(:category_id)
			# 		# intersection_categories = categories & categories_in_united
			# 		missing_categories = categories - categories_in_united
			# 	# msl_united.map{|item|
			# 	# 	if  intersection_categories.include?(item.category_id)
			# 	# 		JcpImplementation.create(category_id: item.category_id,implementation_percentage:item.implementation_percentage,
			# 	# 			reason_id: item.reason_id,share_of_shelve_percentage:item.share_of_shelve_percentage,
			# 	# 			created_at: Time.zone.at(jcp.jcp_date.to_time).to_datetime, updated_at:Time.zone.at(jcp.jcp_date.to_time).to_datetime,promoter_branch_day_id:jcp_id)
			# 	# 	end
			# 		missing_categories.map { |category_id|
			# 	  		JcpImplementation.create(category_id: category_id,implementation_percentage:100,
			# 				reason_id: nil,share_of_shelve_percentage:100,
			# 				created_at:Time.zone.at(jcp.jcp_date.to_time).to_datetime , updated_at:Time.zone.at(jcp.jcp_date.to_time).to_datetime,promoter_branch_day_id:jcp_id)
			# 	  # }

			# 	}

			if retail[0] == 'DAWAA'
				categories_in_dawaa = msl_dawaa.pluck(:category_id)
					intersection_categories = categories & categories_in_dawaa
					missing_categories = categories - categories_in_dawaa
				msl_dawaa.map{|item|
					if  intersection_categories.include?(item.category_id)
						JcpImplementation.create(category_id: item.category_id,implementation_percentage:item.implementation_percentage,
							reason_id: item.reason_id,share_of_shelve_percentage:item.share_of_shelve_percentage,
							created_at: Time.zone.at(jcp.jcp_date.to_time).to_datetime , updated_at:Time.zone.at(jcp.jcp_date.to_time).to_datetime,promoter_branch_day_id:jcp_id)
					end
				}
					missing_categories.map { |category_id|
				  		JcpImplementation.create(category_id: category_id,implementation_percentage:100,
							reason_id: nil,share_of_shelve_percentage:100,
							created_at:Time.zone.at(jcp.jcp_date.to_time).to_datetime , updated_at:Time.zone.at(jcp.jcp_date.to_time).to_datetime,promoter_branch_day_id:jcp_id)
				  }

				# }
			end
		else
			if retail[0] == 'DAWAA'
				categories_in_dawaa = msl_dawaa.pluck(:category_id)
				categoried_in_jcp = msl_branch.pluck(:category_id)
				missing_categories = categories_in_dawaa - categoried_in_jcp
				missing_categories.map { |category_id|
				  		JcpImplementation.create(category_id: category_id,implementation_percentage:100,
							reason_id: nil,share_of_shelve_percentage:100,
							created_at:Time.zone.at(jcp.jcp_date.to_time).to_datetime , updated_at:Time.zone.at(jcp.jcp_date.to_time).to_datetime,promoter_branch_day_id:jcp_id)
				  }
				end


			end 
			end	

	end

	def insert_msl_from_file
		xlsx = Roo::Excelx.new(File.expand_path('./msl_feb.xlsx'))
		integer = []
		xlsx.each_row_streaming(offset: 1) do |row|
			if (row[0] && row[0].value)
				jcp_ids = PromoterBranchDay.joins(:retail_company_branch , :promoter).where(retail_company_branches:{branch_name: row[0].value}, is_visited: 1 ,promoters: {promoter_role_id:2}).where('
					promoter_branch_days.jcp_date >= "2020-03-01" and promoter_branch_days.jcp_date <= "2020-03-31"').pluck(:id)
				items = Item.joins(:brand).where(brands:{project_id: 7} , periority: 1)
				total_msl_items = items.count
				jcp_ids.each do |jcp_id| 
					random_number_of_available = ((row[4].value).to_f*total_msl_items).round
					msl_branch = ItemsAvailability.where(promoter_branch_day_id: jcp_id)
				
					if msl_branch.blank?
						jcp = PromoterBranchDay.find_by_id(jcp_id)
					
						counter = 1
						items.each do |item|
							if (counter <= random_number_of_available)

								ItemsAvailability.create(item_id: item.id,is_available:1,
								created_at: Time.zone.at(jcp.jcp_date.to_time).to_datetime , updated_at:Time.zone.at(jcp.jcp_date.to_time).to_datetime,promoter_branch_day_id:jcp_id)
							elsif ( counter > random_number_of_available)
								ItemsAvailability.create(item_id: item.id,is_available:0,
								created_at: Time.zone.at(jcp.jcp_date.to_time).to_datetime , updated_at:Time.zone.at(jcp.jcp_date.to_time).to_datetime,promoter_branch_day_id:jcp_id)
							end
							counter=counter+1
						end
					end
				end
			end
		end
	end

	def insert_msl
		jcp_ids = PromoterBranchDay.where(promoter_id:params[:promoter_ids],is_visited:1).where('promoter_branch_days.jcp_date >= "2020-03-01" and promoter_branch_days.jcp_date <= "2020-03-31"').pluck(:id)
		items = Item.joins(:brand).where(brands:{project_id: 7} , periority: 1)
		total_msl_items = 73
		jcp_ids.each do |jcp_id|
			random_number_of_available = rand(72..62)
			not_available = total_msl_items- random_number_of_available
			msl_branch = ItemsAvailability.where(promoter_branch_day_id: jcp_id)
			
			if msl_branch.blank?
				jcp = PromoterBranchDay.find_by_id(jcp_id)
			
				counter = 1
				items.each do |item|
					if (counter <= random_number_of_available)

						ItemsAvailability.create(item_id: item.id,is_available:1,
						created_at: Time.zone.at(jcp.jcp_date.to_time).to_datetime , updated_at:Time.zone.at(jcp.jcp_date.to_time).to_datetime,promoter_branch_day_id:jcp_id)
					elsif ( counter > random_number_of_available)
						ItemsAvailability.create(item_id: item.id,is_available:0,
						created_at: Time.zone.at(jcp.jcp_date.to_time).to_datetime , updated_at:Time.zone.at(jcp.jcp_date.to_time).to_datetime,promoter_branch_day_id:jcp_id)
					end
					counter=counter+1
				end
			end
		end
	end
	
	def delete_jco
		PromoterBranchDay.joins(:promoter).joins(retail_company_branch: :retail_company).where(promoters:{promoter_role_id:2}).where(retail_companies: {project_id: 7}).where(promoter_branch_days:{jcp_date: Date.parse("2020-4-1") .. Date.parse("2020-4-30")}).where.not(promoter_branch_days:{id: JcpImplementation.all.map(&:promoter_branch_day_id)} ).destroy_all

	end
	
	private

	def get_jcps_ids(promoter_id)
		PromoterBranchDay.where(promoter_id: promoter_id).where( jcp_date: @d1 .. @d2 ).map(&:id)
	end

	def make_jcps_visited(jpcs_ids_array)
		PromoterBranchDay.where(id: jpcs_ids_array).update_all(is_visited: 1)
	end

	def get_check_in_time
		"#{rand(6..8)}:#{rand(0..30)}:#{rand(0..59)}"
	end

	def get_check_out_time
		"#{rand(10..11)}:#{rand(0..30)}:#{rand(0..59)}"
	end

	def date_range
		
		arr=Array.new

		(@d1 .. @d2).each{|date| arr << date}
		arr
	end

	def get_check_ins_by_jcps(jcp_ids)
		PromoterCheckIn.where(promoter_branch_day_id: jcp_ids).map(&:id)
	end

end
