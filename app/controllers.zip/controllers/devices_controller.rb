class DevicesController < ApplicationController
      before_action :authenticate_user!

  before_action :set_device, only: [:show, :update, :destroy]

  # GET /devices
  def index
    project_id = current_user.project_id
    brand_id = params[:brand_id].blank? ? 
     Brand.where(project_id:project_id).pluck(:id) :
     params[:brand_id] 
    category_id = params[:category_id].blank? ?
     Category.where(project_id: project_id).pluck(:id) : 
     params[:category_id]
    item_id = params[:item_id].blank? ? 
     Item.joins(:brand , :category).where(brands: {project_id: project_id,
      id:brand_id},categories:{id:category_id}).pluck(:id) : 
      params[:item_id]

    @devices = Device.joins(item: [:brand , :category])
    .where(item_id:item_id)
    .select('devices.* , items.item_name , brands.brand_name , categories.category_name')
    .order(id: :desc)

    render json: @devices
  end

  # GET /devices/1
  def show
    render json: @device
  end

  # POST /devices
  def create
    @device = Device.find_by(item_id:params[:item_id],device_name: params[:device_name])
    if @device
        render json: {'msg': 'Already exists!'} , status: 422
    else
        @device = Device.new(item_id:params[:item_id],device_name: params[:device_name])
        if @device.save
          render json: @device, status: :created, location: @device
        else
          render json: @device.errors, status: :unprocessable_entity
        end
    end
  end

  # PATCH/PUT /devices/1
  def update
    if @device.update(device_params)
      render json: @device
    else
      render json: @device.errors, status: :unprocessable_entity
    end
  end

  # DELETE /devices/1
  def destroy
    @device.destroy
  end

  

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_device
      @device = Device.find(params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def device_params
      params.require(:device).permit(:device_name, :item_id)
    end
end
