class JcpController < ApplicationController
	before_action :authenticate_user!


	def list_jcps
		date_range = get_date_range(params[:start_date],params[:end_date])
	    branch_conditions = {}
		branch_conditions[:id] = params[:branch_id].blank? ? RetailCompanyBranch.joins(:retail_company)
	    .where(retail_companies: {project_id: current_user.project_id},retail_company_branches:{is_deleted:"0"}).map(&:id) : params[:branch_id]
	    is_visited=params[:is_visited].blank? ? [1,0] : params[:is_visited]
	    # puts current_user.project_id
	    render json: PromoterBranchDay.joins(:retail_company_branch)
	    .where(promoter_branch_days:date_range)
	    	.where(promoter_id:params[:promoter_id])
	    .where(retail_company_branches:branch_conditions)
	    	
	end

	private
	def get_date_range(start_date_param,end_date_param)
		date_range={}

		if start_date_param
			start_date=Date.parse(params[:start_date]).beginning_of_day
		else
			start_date=Date.today.beginning_of_day
		end

		if end_date_param
			end_date=Date.parse(params[:end_date]).end_of_day
		else
			end_date=Date.today.end_of_day
		end

		date_range[:created_at]=start_date .. end_date
		date_range
	end

end
