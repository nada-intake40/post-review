class DataController < ApplicationController
	require 'roo'
	include Utils
	# before_action :set_vars
	
	def initialize()
		@missing_promoters=Array.new
	end

	def import_jcps
		promoter_indexs=Array.new
		branch_indexs=Array.new
		problem_index=0
		encode_from_base64("./jcps.xlsx",params["file_string"].split("base64,")[1])
		xlsx = Roo::Excelx.new(File.expand_path('./jcps.xlsx'))
		xlsx.each_row_streaming(offset: 1) do |row|
			problem_index = problem_index + 1
			if (row[0] && row[1] && row[2] && row[0].value && row[1].value && row[2].value )
				promoter=Promoter.find_by_username(row[0].value)
				branch=RetailCompanyBranch.find_by(branch_name:row[1].value,is_deleted:0)
				if (promoter)    
					
					if (branch)
						String(row[2].value).split(",").map { | date_string |
							visit=PromoterBranchDay.find_by(jcp_date:date_string,promoter_id:promoter.id,retail_company_branch_id:branch.id,is_visited:0)
							if (! visit)
								PromoterBranchDay.create(jcp_date:date_string,promoter_id:promoter.id,retail_company_branch_id:branch.id,is_visited:0)
							end
						}
					else
						branch_indexs << problem_index
					end
					
				else
					promoter_indexs << problem_index 
				end
			end
		end

		if promoter_indexs.count == 0 && branch_indexs.count == 0
			render json: "success "
		else
			render json: {"promoters_in_indexes":promoter_indexs,"branches_in_indexes":branch_indexs},:status => "500"
		end
	end

	def import_items
		xlsx = Roo::Excelx.new(File.expand_path('./item.xlsx'))
		xlsx.each_row_streaming(offset: 1) do |row|
						periority= row[2].value == "Yes" ? 1 : 0 

			category_id= get_category_id row[6].value
			item_id= get_item_id row[1].value, category_id , periority, row[5].value
			device=Device.find_by(device_name:row[0].value,item_id:item_id )
			if ! device
				Device.create(device_name:row[0].value,item_id:item_id )
			end
		end
		render json: "success"

	end

	def update_visits
		# IMPORTANT
		# you need to check sheet name
		xlsx = Roo::Excelx.new(File.expand_path('./absence.xlsx'))
		xlsx.each_row_streaming(offset: 1) do |row|
			not_visited=Array.new

			if (row[3] && row[3].value !="-")
				not_visited =  not_visited + get_dates(row[3].value)
				puts "1>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
				
			end

			if (row[1] && row[2] && row[1].value != "-" && row[2].value != "-" )
				not_visited =  not_visited + get_dates_in_range(row[1].value,row[2].value)
				puts "2>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
			end


			
			update_visits_in_dates_arr(row[0].value,not_visited)

			if( row[1] && row[2] && row[3] && row[1].value =="-"  && row[2].value =="-"  && row[3].value =="-" )
					update_all_visits(row[0].value)
					puts "3>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"					
			end

		end
		render json: "success #{@missing_promoters}"


	end


	def add_custom_absents
		# IMPORTANT
		# you need to check sheet name
		xlsx = Roo::Excelx.new(File.expand_path('./Absence-by-Store.xlsx'))
		index=1
		branches_indexs=Array.new
		promoters_indexs=Array.new
		xlsx.each_row_streaming(offset: 1) do |row|
			index=index+1
			if (row[0] && row[1] && row[2] && row[0].value && row[1].value && row[2].value)
				puts "=================================== > #{row[0].value}" 
				branch=RetailCompanyBranch.find_by_branch_name(row[1].value)
				if (! branch)
				
					branches_indexs << index
					next
				else
					
				end

				promoter=Promoter.find_by_username(row[0].value)
				if (! promoter)
				
					promoters_indexs << index
					next
				end

				if (promoter&&branch)
					unvisit_store_date(promoter.username,row[2].value,branch.id)

				end
			end

		end
		render json: "success , branch error in #{branches_indexs} & promoter errors #{promoters_indexs}"


	end

	private

	def update_visits_in_dates_arr(username,not_visited_dates_arr)
		promoter=Promoter.find_by_username(username.downcase.delete(" "))
		if ! promoter
			@missing_promoters << username.downcase.delete(" ")
			return
		end
		
		# IMPORTANT
		# you need to check outter range
		visits=PromoterBranchDay
		.where(jcp_date: turn_to_date("1") .. turn_to_date("31"))
		.where(promoter_id:promoter.id)
		.where.not(jcp_date: not_visited_dates_arr)
		
		visits.map { |visit|
			visit.is_visited = 1
			visit.save
			add_check_in_record(promoter.id,visit.id)

		}
	end

	def update_all_visits(username)
		promoter=Promoter.find_by_username(username.downcase.delete(" "))
		if ! promoter
			@missing_promoters << username.downcase.delete(" ")
			return
		end
		# IMPORTANT
		# you need to check outter range

		visits=PromoterBranchDay
		.where(jcp_date: turn_to_date("1") .. turn_to_date("31"))
		.where(promoter_id:promoter.id)		
		visits.map { |visit|
			visit.is_visited = 1
			visit.save
			add_check_in_record(promoter.id,visit.id)

		}

	end

	def turn_to_date(no)
		# IMPORTANT
		# you need to check month
		"2020-3-#{no}".to_date
	end

	def get_dates_in_range(from,to)
		dates=Array.new

		range=turn_to_date(from) .. turn_to_date(to) 
		range.map { |date| dates << date }
		dates

	end

	def get_dates(date_string)
		dates=Array.new
		String(date_string).split(",").map { |no|
			dates << turn_to_date(no)
		}

		dates
	end



	def unvisit_store_date(username,not_visited_date,store_id)
		promoter=Promoter.find_by_username(username.downcase.delete(" "))
		if ! promoter
			@missing_promoters << username.downcase.delete(" ")
			return
		end

		visits=PromoterBranchDay
		.where(promoter_id:promoter.id,retail_company_branch_id:store_id)
		.where(jcp_date: not_visited_date)
		
		visits.map { |visit|
			visit.is_visited = 0
			visit.save
			PromoterCheckIn.where(promoter_branch_day_id: visit.id).destroy_all

		}
	end

	# def update_visits_in_range(username,from,to)
	# 	promoter=Promoter.find_by_username(username.downcase.delete(" "))
	# 	if ! promoter
	# 		@missing_promoters << username.downcase.delete(" ")
	# 		return
	# 	end
	# 	visits=PromoterBranchDay
	# 	.where(jcp_date: turn_to_date("1") .. turn_to_date("29"))
	# 	.where(promoter_id:promoter.id)
	# 	.where.not(jcp_date: turn_to_date(from) .. turn_to_date(to))
		
	# 	visits.map { |visit|
	# 		visit.is_visited = 1
	# 		visit.save
	# 		add_check_in_record(promoter.id,visit.id)

	# 	}
	# end

	# def update_visits_in_dates(username,date_string)
	# 	promoter=Promoter.find_by_username(username.downcase.delete(" "))
	# 	if ! promoter
	# 		@missing_promoters << username.downcase.delete(" ")
	# 		return
	# 	end

	# 	date_arr=Array.new
	# 	String(date_string).split(",").map { |no|
	# 		date_arr << turn_to_date(no)
	# 	}
	# 	visits = PromoterBranchDay
	# 	.where(jcp_date: turn_to_date("1") .. turn_to_date("29"))
	# 	.where(promoter_id:promoter.id)
	# 	.where.not(jcp_date: date_arr)
		
	# 	visits.map { |visit|
	# 		visit.is_visited = 1
	# 		visit.save
	# 		add_check_in_record(promoter.id,visit.id)

	# 	}

	# end

	

	def add_check_in_record(promoter_id,visit_id)
		visit=PromoterBranchDay.find(visit_id)
		check_in=PromoterCheckIn.find_by(promoter_id:promoter_id,promoter_branch_day_id: visit_id)
		if check_in
			check_in.check_out_time = get_check_out_time(visit.jcp_date)
			check_in.save
		else
			check_in=PromoterCheckIn.new(promoter_id:promoter_id,latitude:"--",longitude:"--",check_in_state_id:1,date:visit.jcp_date,
				created_at: "#{visit.jcp_date} 9:30:00",updated_at:"#{visit.jcp_date} 9:30:00",
				check_out_time:get_check_out_time(visit.jcp_date),promoter_branch_day_id:visit_id
			)
			check_in.save
		end
	end

	def get_check_out_time(jcp_date)
		"#{jcp_date} 22:30:00"
	end

	def get_category_id category_name
		category=Category.find_by_category_name(category_name)
		if category
			return category.id
		else
			category = Category.new({category_name:category_name,project_id:7 })
			category.save
			return category.id
		end
	end

	def get_item_id item_name, category_id, periority, volume
		item=Item.find_by(item_name: item_name, category_id: category_id,brand_id:25)
		if item
			return item.id
		else
			item = Item.new({item_name: "#{item_name} - #{volume}",category_id: category_id,brand_id: 25,periority: periority })
			item.save
			return item.id
		end
	end

	# def set_vars
	# 	@project_id=7
	# 	@brand_id=25
	# end


	
end
