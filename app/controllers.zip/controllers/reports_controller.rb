class ReportsController < ApplicationController
	require 'axlsx'
	include ReportsHelper
  	before_action :authenticate_user!,except: [:all_branches]
	
	
	def sales_report
		date_range={}

		if params[:start_date]
			start_date=Date.parse(params[:start_date]).beginning_of_day
		else
			start_date=Date.today.beginning_of_day
		end

		if params[:end_date]
			end_date=Date.parse(params[:end_date]).end_of_day
		else
			end_date=Date.today.end_of_day
		end

		date_range[:created_at]=start_date .. end_date
		package = Axlsx::Package.new
		workbook = package.workbook
		sheet = workbook.add_worksheet(name: "Sales Report")
		devices = all_devices_with_items(current_user.project_id)
		branches = RetailCompanyBranch.joins(:retail_company)
			.where(retail_companies: {project_id:current_user.project_id})
			.select("retail_company_branches.id,retail_company_branches.branch_name")
		sheet.add_row ['Branch Name/Device Name'] + devices.map{ |device| device[:name]}
		branches.each  { |branch|
			row=[branch[:branch_name]]
			devices.each  { |device|
				row << get_device_sales_in_branch(device[:id],branch[:id],date_range)
			}
			# byebug
			sheet.add_row row

		}
		package.serialize "demo.xls"
		send_file("demo.xls", filename: "stock report.xls", type: "application/vnd.ms-excel")
	end

	def stock_report
		date_range={}

		if params[:start_date]
			start_date=Date.parse(params[:start_date]).beginning_of_day
		else
			start_date=Date.today.beginning_of_day
		end

		if params[:end_date]
			end_date=Date.parse(params[:end_date]).end_of_day
		else
			end_date=Date.today.end_of_day
		end

		date_range[:created_at]=start_date .. end_date
		package = Axlsx::Package.new
		workbook = package.workbook
		sheet = workbook.add_worksheet(name: "Stock Report")
		devices = all_devices_with_items(current_user.project_id)
		branches = RetailCompanyBranch.joins(:retail_company)
			.where(retail_companies: {project_id:current_user.project_id})
			.select("retail_company_branches.id,retail_company_branches.branch_name")

		sheet.add_row ['Branch Name/Device Name']     + devices.map{ |device| device[:name]}
		branches.each  { |branch|
			row=[branch[:branch_name]]
			devices.each  { |device|
				row << get_device_stock_in_branch(device[:id],branch[:id],date_range)
			}
			# byebug
			sheet.add_row row

		}
		package.serialize "demo.xls"
		send_file("demo.xls", filename: "stock report.xls", type: "application/vnd.ms-excel")
	end

	def new_sales_report
		date_range = get_date_range(params[:start_date],params[:end_date])
		package = Axlsx::Package.new
		workbook = package.workbook
		sheet = workbook.add_worksheet(name: "Sales Report")
		sales = InvoiceDevice.joins(invoice: {retail_company_branch: :retail_company})
		.where(invoice_devices:date_range)
		.where(retail_companies: {project_id:current_user.project_id})
		
		sheet.add_row ["Date","City","Chain","Branch","Model","Volume","Value"]
		sales.map { | sale|
			sheet.add_row [ sale.created_at.strftime("%Y-%m-%d"),sale.invoice.retail_company_branch.city.city_name,
			sale.invoice.retail_company_branch.retail_company.retail_company_name, sale.invoice.retail_company_branch.branch_name,
			"#{sale.device.item.item_name} - #{sale.device.device_name}", sale.quantity,Float(sale.quantity)*Float(sale.price)
			]
		}

		package.serialize "demo.xls"
		send_file("demo.xls", filename: "sales report.xls", type: "application/vnd.ms-excel")

	end


	def voc_report
		date_range={}

		if params[:start_date]
			start_date=Date.parse(params[:start_date]).beginning_of_day
		else
			start_date=Date.today.beginning_of_day
		end

		if params[:end_date]
			end_date=Date.parse(params[:end_date]).end_of_day
		else
			end_date=Date.today.end_of_day
		end

		date_range[:created_at]=start_date .. end_date
		package = Axlsx::Package.new
		workbook = package.workbook
		sheet = workbook.add_worksheet(name: "VOC Report")
		sheet.add_row ['Retail','Branch','Customer Feedback']
		voc = Feedback.joins(retail_company_branch: :retail_company).joins(:promoter)
		.where(retail_companies: {project_id:current_user.project_id},feedbacks:date_range)
		.select("retail_companies.retail_company_name,retail_company_branches.branch_name,feedbacks.feedback_body")
		voc.map { |feedback|  

			sheet.add_row [feedback.retail_company_name , feedback.branch_name , feedback.feedback_body]

		}
		package.serialize "demo.xls"
		send_file("demo.xls", filename: "stock report.xls", type: "application/vnd.ms-excel")
	end
	
	def competitors_report
		date_range={}

		if params[:start_date]
			start_date=Date.parse(params[:start_date]).beginning_of_day
		else
			start_date=Date.today.beginning_of_day
		end

		if params[:end_date]
			end_date=Date.parse(params[:end_date]).end_of_day
		else
			end_date=Date.today.end_of_day
		end

		date_range[:created_at]=start_date .. end_date
		package = Axlsx::Package.new
		workbook = package.workbook
		sheet = workbook.add_worksheet(name: "Competitors Report")
		sheet.add_row ['Retail','Branch','Brand', 'Item','Quantity','Price']
		competitors = Competitor.joins(:brand).joins(retail_company_branch: :retail_company)
						.where(competitors:date_range)
						.select("retail_companies.retail_company_name,retail_company_branches.branch_name,brands.brand_name,competitors.*")
		competitors.map { |comp|  
		
			sheet.add_row [comp.retail_company_name , comp.branch_name,  comp.brand_name, comp.item_name, comp.quantity, comp.price]
		}				

		package.serialize "demo.xls"
		send_file("demo.xls", filename: "stock report.xls", type: "application/vnd.ms-excel")

	end

	def attendence_report2
		date_range={}

		if params[:start_date]
			start_date=Date.parse(params[:start_date])
		else
			start_date=Date.today
		end

		if params[:end_date]
			end_date=Date.parse(params[:end_date])
		else
			end_date=Date.today
		end
		date_range[:created_at]=start_date .. end_date
		package = Axlsx::Package.new
		workbook = package.workbook
		sheet = workbook.add_worksheet(name: "attendence_report")
		branches=RetailCompanyBranch.joins(:retail_company).where(retail_companies:{project_id:current_user.project_id})
		sheet.add_row ['Date','Retail','Branch','Attended', 'Absent','Total']

		date_range[:created_at].map { |date|  

			branches.map { |branch|  
				sheet.add_row get_attendence_record_in_date(branch,date)

			}

		}
		package.serialize "demo.xls"
		send_file("demo.xls", filename: "attendence_report.xls", type: "application/vnd.ms-excel")
	end
	
	def attendence_report
		date_range={}

		if params[:start_date]
			start_date=Date.parse(params[:start_date])
		else
			start_date=Date.today
		end

		if params[:end_date]
			end_date=Date.parse(params[:end_date])
		else
			end_date=Date.today
		end
		date_range[:created_at]=start_date .. end_date
		package = Axlsx::Package.new
		workbook = package.workbook
		sheet = workbook.add_worksheet(name: "Competitors Report")
		visits=PromoterBranchDay.joins(retail_company_branch: :retail_company)
			.where(retail_company_branches: {is_deleted:0})
			.where(retail_companies:{project_id:current_user.project_id})
			.where(jcp_date: date_range[:created_at])
			.where(retail_company_branches:{is_deleted:0})

		sheet.add_row ['Date','CITY','CHAIN','STORE','USERNAME', 'VISITED','ROLE']

		visits.map { |visit|
		sheet.add_row [visit.jcp_date,visit.retail_company_branch.city.city_name,
			visit.retail_company_branch.retail_company.retail_company_name,visit.retail_company_branch.branch_name,
			visit.promoter.username, PromoterCheckIn.where(promoter_branch_day_id: visit.id).count == 0 ? 0 : 1,
			visit.promoter.promoter_role.promoter_role_title
		
		]
		}
		package.serialize "demo.xls"
		send_file("demo.xls", filename: "attendence_report.xls", type: "application/vnd.ms-excel")
	end

	def raw_data_report
		date_range={}

		if params[:start_date]
			start_date=Date.parse(params[:start_date])
		else
			start_date=Date.today
		end

		if params[:end_date]
			end_date=Date.parse(params[:end_date])
		else
			end_date=Date.today
		end
		data_range=(start_date .. end_date).map{ |date| date.strftime("%Y-%m-%d") }
		package = Axlsx::Package.new
		workbook = package.workbook
		sheet = workbook.add_worksheet(name: "Raw Data Report")
		branches=RetailCompanyBranch.joins(:retail_company).where(retail_companies:{project_id:current_user.project_id})
		sheet.add_row ['Date','Retail','Branch','Brand', 'Item','Device','Qty','Price','Total']
		# byebug
		data_range.map { |date_string|  
			date=Date.parse(date_string)
			branches.map { |branch|  
				rows=get_raw_data_in_date(branch,date)
				rows.map{|row|
					sheet.add_row row
				}
			}
			

		}
		package.serialize "demo.xls"
		send_file("demo.xls", filename: "attendence_report.xls", type: "application/vnd.ms-excel")
	end

	def jcp_report
		date_range={}

		if params[:start_date]
			start_date=Date.parse(params[:start_date])
		else
			start_date=Date.today
		end

		if params[:end_date]
			end_date=Date.parse(params[:end_date])
		else
			end_date=Date.today
		end
		date_range[:created_at]=start_date .. end_date

		package = Axlsx::Package.new
		workbook = package.workbook
		sheet = workbook.add_worksheet(name: "Journy Plan")
		jcps=PromoterBranchDay.joins(:retail_company_branch)
				.where(retail_company_branches: {is_deleted:0})
				.where(jcp_date: date_range[:created_at] ).order("retail_company_branches.store_class_id")
		sheet.add_row ['COMPANY','CITY','CHAIN','STORE', 'USERNAME'] + get_days_names()
		jcps.map { |jcp|  
			sheet.add_row [jcp.promoter.project.project_name , jcp.retail_company_branch.city.city_name,
				jcp.retail_company_branch.retail_company.retail_company_name,jcp.retail_company_branch.branch_name,
				jcp.promoter.username] + get_visited_record_of_promoter(jcp.promoter,jcp.retail_company_branch)

			

		}
		package.serialize "demo.xls"
		send_file("demo.xls", filename: "jcp.xls", type: "application/vnd.ms-excel")

	end

	def jcp_reporttt
		date_range={}

		if params[:start_date]
			start_date=Date.parse(params[:start_date])
		else
			start_date=Date.today
		end

		if params[:end_date]
			end_date=Date.parse(params[:end_date])
		else
			end_date=Date.today
		end
		date_range[:created_at]=start_date .. end_date

		package = Axlsx::Package.new
		workbook = package.workbook
		sheet = workbook.add_worksheet(name: "Journy Plan")
		branches=RetailCompanyBranch.joins(:retail_company).joins(promoter_branch_days: :promoter)
		.where(retail_companies:{project_id:current_user.project_id})
		.where(promoters: {promoter_role_id: 2})
		.where(retail_company_branches:{is_deleted: 0})
		.where(promoter_branch_days:{jcp_date: date_range[:created_at]})
		.uniq{|x| x.id}

		sheet.add_row ['COMPANY','CITY','CHAIN','STORE', 'ACTUAL','PLANED']
		branches.map { |branch|  
			sheet.add_row [branch.retail_company.project.project_name , branch.city.city_name,
				branch.retail_company.retail_company_name,branch.branch_name, get_actual_jcb_in_branch(branch,date_range[:created_at]), 
				get_planned_jcb_in_branch(branch,date_range[:created_at])]
			

		}
		package.serialize "demo.xls"
		send_file("demo.xls", filename: "jcp.xls", type: "application/vnd.ms-excel")

	end


	def msl_report
		package = Axlsx::Package.new
		workbook = package.workbook
		sheet = workbook.add_worksheet(name: "MSL Report")
		date_range = get_date_range(params[:start_date],params[:end_date])
		msl_records = ItemsAvailability.joins(promoter_branch_day: {retail_company_branch: :retail_company})
						.where(items_availabilities: date_range)
		
		sheet.add_row ['DATE','CITY','CHAIN','STORE', 'CATEGORY','BRAND','ITEM','AVAILABLE','STATUS']
				
		msl_records.map { |msl|
			sheet.add_row [msl.created_at.strftime("%Y-%m-%d"),	msl.promoter_branch_day.retail_company_branch.city.city_name,
			msl.promoter_branch_day.retail_company_branch.retail_company.retail_company_name,msl.promoter_branch_day.retail_company_branch.branch_name,
			msl.item.category.category_name,msl.item.brand.brand_name,msl.item.item_name,msl.is_available
			]
		}
		package.serialize "demo.xls"
		send_file("demo.xls", filename: "msl.xls", type: "application/vnd.ms-excel")

	end
	
	def share_of_shelf
		package = Axlsx::Package.new
		workbook = package.workbook
		sheet = workbook.add_worksheet(name: "SOS Report")
		date_range = get_date_range(params[:start_date],params[:end_date])
		sos_records = JcpImplementation.joins(promoter_branch_day: {retail_company_branch: :retail_company})
						.where(promoter_branch_days: {jcp_date: date_range[:created_at]})
						.where(retail_companies:{project_id: current_user.project_id})
		sheet.add_row ['DATE','CITY','CHAIN','STORE', 'CATEGORY','NIVEA%']
				
		sos_records.map { |sos|
		
			sheet.add_row [sos.promoter_branch_day.jcp_date.strftime("%Y-%m-%d"),	sos.promoter_branch_day.retail_company_branch.city.city_name,
			sos.promoter_branch_day.retail_company_branch.retail_company.retail_company_name,sos.promoter_branch_day.retail_company_branch.branch_name,
			sos.category.blank? ? "" : sos.category.category_name,sos.share_of_shelve_percentage
			]
		}
		package.serialize "demo.xls"
		send_file("demo.xls", filename: "SOS.xls", type: "application/vnd.ms-excel")

	end

	def msl_overview_report
		package = Axlsx::Package.new
		workbook = package.workbook
		sheet = workbook.add_worksheet(name: "MSL OVERVIEW Report")
		date_range = get_date_range(params[:start_date],params[:end_date])
		jcps = PromoterBranchDay.joins(retail_company_branch: :retail_company)
				.joins(:items_availabilities)
				.where(retail_companies:{project_id:current_user.project_id})
				.where(jcp_date: date_range[:created_at])
				.group('promoter_branch_days.id')

		sheet.add_row ['DATE','CITY','CHAIN','STORE', 'USERNAME' ,'AVAILABLE MSL','NOT AVAILABLE MSL','TOTAL ITEMS','PERCENTAGE%']
		jcps.map { |visit|
			high_available_item_count=ItemsAvailability.where(promoter_branch_day_id:visit.id).count

		
			available_counts=ItemsAvailability.where(promoter_branch_day_id:visit.id,is_available:1).count
			percentage=(available_counts*100)/Float(high_available_item_count)
			
			sheet.add_row [ visit.jcp_date, visit.retail_company_branch.city.city_name,
				visit.retail_company_branch.retail_company.retail_company_name, visit.retail_company_branch.branch_name,
				visit.promoter.username,available_counts, 
				high_available_item_count-available_counts , high_available_item_count ,"#{percentage.round(2)}%" ]

		}
		package.serialize "demo.xls"
		send_file("demo.xls", filename: "MSL.xls", type: "application/vnd.ms-excel")



	end


	def planogram_report
		package = Axlsx::Package.new
		workbook = package.workbook
		sheet = workbook.add_worksheet(name: "Planogram Report")
		date_range = get_date_range(params[:start_date],params[:end_date])
		planograms = JcpImplementation.joins(promoter_branch_day: {retail_company_branch: :retail_company})
						.where(promoter_branch_days: {jcp_date: date_range[:created_at]})
						.where(retail_companies:{project_id: current_user.project_id})
		sheet.add_row ['DATE','CITY','CHAIN','STORE', 'USERNAME' , 'CATEGORY', 'IMPL. PERCENTAGE' ,'REASON']
				
		planograms.map { |planogram|
		
			sheet.add_row [planogram.promoter_branch_day.jcp_date.strftime("%Y-%m-%d"),	planogram.promoter_branch_day.retail_company_branch.city.city_name,
			planogram.promoter_branch_day.retail_company_branch.retail_company.retail_company_name,
			planogram.promoter_branch_day.retail_company_branch.branch_name, planogram.promoter_branch_day.promoter.username,
			planogram.category.blank? ? "" : planogram.category.category_name,planogram.implementation_percentage,
			planogram.implementation_percentage == 100 ? "IMPLEMENTED" : planogram.reason.blank? ? "": planogram.reason.name
			]
		}
		package.serialize "demo.xls"
		send_file("demo.xls", filename: "Planogram.xls", type: "application/vnd.ms-excel")

	end

	def all_branches
		package = Axlsx::Package.new
		workbook = package.workbook
		sheet = workbook.add_worksheet(name: "Branches")
		branches = RetailCompanyBranch.joins( :retail_company)
						.where(retail_companies:{project_id: 7})
						.where(is_deleted:0)
		sheet.add_row ['CITY','CHAIN','STORE']
				
		branches.map { |branch|
		
			sheet.add_row [branch.city.city_name,	branch.retail_company.retail_company_name,branch.branch_name	]
		}
		package.serialize "demo.xls"
		send_file("demo.xls", filename: "branches.xls", type: "application/vnd.ms-excel")


	end



	private
	def get_actual_jcb_in_branch(branch,data_range)
		count=0
		
		visits=PromoterBranchDay.joins(:promoter)
		.where(promoters: {promoter_role_id: 2})
		.where(retail_company_branch_id:branch.id,jcp_date:data_range)

		visits.map { |visit|
			if( PromoterCheckIn.where(promoter_branch_day_id: visit.id).count > 0 )
				count = count +1
			end
		}
		count

	end
	def get_planned_jcb_in_branch(branch,data_range)
		PromoterBranchDay.joins(:promoter)
		.where(promoters: {promoter_role_id: 2})
		.where(retail_company_branch_id:branch.id,jcp_date:data_range).count

	end
	def get_visited_record_of_promoter(promoter,branch)
		records=Array.new
		(Date.today .. Date.today + 6.days ).each do |day|
			date = day.strftime("%Y-%m-%d")
			jcp=PromoterBranchDay.find_by(promoter_id:promoter.id,
				retail_company_branch_id:branch.id,jcp_date:date,is_visited: "y")
			if jcp 
				records << "1"
			else
				records << "0"
			end
		end

		records

	end


	def get_days_names()
		days=Array.new
		(Date.today .. Date.today + 6.days ).each do |day|
			days << day.strftime("%A")
		end
		days

	end

	def get_date_range(start_date_param,end_date_param)
		date_range={}

		if start_date_param
			start_date=Date.parse(params[:start_date]).beginning_of_day
		else
			start_date=Date.today.beginning_of_day
		end

		if end_date_param
			end_date=Date.parse(params[:end_date]).end_of_day
		else
			end_date=Date.today.end_of_day
		end

		date_range[:created_at]=start_date .. end_date
		date_range
	end


end
