
class ItemsController < ApplicationController
	require "base64"
  include PromoterHelper
	include ChartsHelper
  	before_action :authenticate_user!

  	def getListOfHighPeriorityItems
  		project_id = current_user.project_id
    	items = Item.joins(brand: :project)
    	.where(periority:true)
      	.where(projects:{id:project_id})
    	render json: items 
  	end

  	def get_list_of_checked_msl
        is_available = params[:is_available].blank? ? [0,1] : params[:is_available]
  		items = ItemsAvailability.joins(item: :category).where(promoter_branch_day_id:params[:jcp_id],is_available:is_available)
  		.select('items_availabilities.is_available , items.item_name , items.item_image , categories.category_name , 
  			items_availabilities.id')
		render json: items 
  	end

  	def get_numbers_of_items
  		items = ItemsAvailability.where(promoter_branch_day_id:params[:jcp_id])
		all_items_count = items.count
		available_items_count = items.where(is_available:true).count
		unavailable_items_count = items.where(is_available:false).count
		render json: {'all_items_count': all_items_count , 'available_items_count': available_items_count ,'unavailable_items_count': unavailable_items_count }
  	end

  	

	def get_total_out_of_stock_count
	    project_id=current_user.project_id
	    render json: OutOfStock.joins(retail_company_branch: :retail_company).where("retail_companies.project_id = #{project_id}").count

	end

	def edit_item
		item = Item.find(params[:item_id]).update(item_name:params[:item_name],periority:params[:periority])
		render json: item
	end

	def get_items
		project_id = current_user.project_id
		brand_id = params[:brand_id].blank? ? Brand.where(project_id:project_id) : params[:brand_id]
		category_id = params[:category_id].blank? ? Category.where(project_id:project_id) : params[:category_id]
		render json: Item.joins(:brand)
		.where(brands:{project_id:project_id }, brand_id: brand_id,
			category_id: category_id).select("items.*")

	end

	def delete_item
		item=Item.find(params[:item_id])
		ItemsAvailability.where(item_id: item).destroy_all
		Device.where(item_id: item).destroy_all
		item.destroy
	end

	def add_item
		item = Item.find_by(item_name:params[:item_name],category_id:params[:category_id],brand_id:params[:brand_id])
		if item
			render json: {'msg': 'Item already exists!'} , status: 422
		else
			item = Item.new({item_name:params[:item_name],category_id:params[:category_id],brand_id:params[:brand_id],periority:params[:periority]})
			if item.save
				img_split = params[:image_string].split(',')
				ext_split = img_split[0].split('/')
				ext = ext_split[1].split(";")
				image_path = get_item_image_dir(item.id,ext[0])
	        	image_string = img_split[1]
	        	save_item_image(image_string,image_path)
	        	item.item_image = image_path
	        	item.save
		      render json: item, status: :created
		    else
		      render json: item.errors, status: :unprocessable_entity
		    end
		end

	end

	def get_all_items
		render json: Item.joins(:brand).where(brands: {project_id:current_user.project_id})
	end

	def stock_line_chart
		resp={}
		resp["date_range"] = get_date_range(params[:start_date],params[:end_date],current_user.project_id)
		item_list=get_items_in_project(current_user.project_id,params[:start_date],params[:end_date])
		resp["items_list"]=Array.new
		item_list.map { |item|  
			resp["items_list"] << item_stock_in_date_range(item,resp["date_range"],params)
		}
		# byebug
		render json:resp
	end

	def oos_raw_data
		branch_conditions = {}
		retail_conditions = {}
		city_conditions = {}
	    retail_conditions[:id] = params[:retail_id].blank? ?  RetailCompany.where(project_id:current_user.project_id).map(&:id) : params[:retail_id] 
	    city_conditions[:id] = params[:city_id].blank? ? City.where(project_id:current_user.project_id).map(&:id) :  params[:city_id]
	    branch_conditions[:id] = params[:branch_id].blank? ? RetailCompanyBranch.joins(:retail_companies)
	    .where(retail_companies: {id: current_user.project_id}).map(&:id) : params[:branch_id]
	    
	    date_range={}

	    if params[:date]
	    	date_range[:created_at]=DateTime.parse(params[:date]).beginning_of_day .. DateTime.parse(params[:date]).end_of_day
	    end

	    render json: OutOfStock.joins(retail_company_branch: [:retail_company,:city],device: {item: [:brand,:category]})
	    .where(retail_company_branches:branch_conditions,out_of_stocks:date_range)
		.where(retail_companies: {project_id: current_user.project_id})
		.where(retail_company_branches: branch_conditions)
		.where(cities: city_conditions)



	end

	def filter_items
		brand = params[:brand]
		category = params[:category]
		periority = params[:periority]
		project_id = current_user.project_id
	
	
		conditions = {}
		conditions[:brand_id] = params[:brand] unless params[:brand].blank?
		conditions[:category_id] = params[:category] unless params[:category].blank?
		conditions[:periority] = params[:periority] unless params[:periority].blank?
	
	
			
		items = Item.joins(:brand).where(conditions).where(brands: {project_id: "#{project_id}"}).select("items.*")
	   
		if(items)
		  render json: items ,status: 200
	   else
		  render json: items.errors , status: 422
		end
	end

end


def save_item_image(image_string,image_path)
      

      File.open("public/#{image_path}", 'wb') do |f|
        f.write(Base64.decode64(image_string))
      end
end

