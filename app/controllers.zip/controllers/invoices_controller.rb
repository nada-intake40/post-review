class InvoicesController < ApplicationController
	before_action :authenticate_user!
	include ChartsHelper

	def list_invoices
	    retail_id = params[:retail_id].blank? ?  RetailCompany.where(project_id:current_user.project_id).pluck(:id) : params[:retail_id] 
	    city_id = params[:city_id].blank? ? City.where(project_id:current_user.project_id).pluck(:id) :  params[:city_id]
	    branch_id = params[:branch_id].blank? ? RetailCompanyBranch.joins(:retail_company)
	    .where(retail_companies: {project_id: current_user.project_id}).pluck(:id) : params[:branch_id]
	    start_date = params[:start_date].blank? ? (Date.today-7).beginning_of_day 
	    : Date.parse(params[:start_date]).beginning_of_day
	    end_date = params[:end_date].blank? ? (Date.today.end_of_day) 
	    : Date.parse(params[:end_date]).end_of_day

		render json: InvoiceDevice.joins(invoice: {retail_company_branch: [:retail_company,:city]})
		.joins(device: {item: [:brand,:category]})
		.where(retail_company_branches: {id:branch_id} ,
		retail_companies: {id:retail_id},cities: {id:city_id}).where(
		'invoice_devices.created_at >= ? AND invoice_devices.created_at <= ?', start_date ,end_date)
		.select("invoices.id,invoices.created_at,cities.city_name,retail_companies.retail_company_name,retail_company_branches.branch_name,brands.brand_name,categories.category_name,items.item_name,devices.device_name,invoice_devices.price,invoice_devices.quantity,(invoice_devices.quantity*invoice_devices.price) AS total")
	end

	def sales_quantity_chart
		resp={}
		resp["date_range"] = get_date_range(params[:start_date],params[:end_date],current_user.project_id)
		item_list=get_items_in_project(current_user.project_id,params[:start_date],params[:end_date])
		resp["items_list"]=Array.new
		item_list.map { |item|  
			resp["items_list"] << item_sales_in_date_range(item,resp["date_range"],params)
		}
		# byebug
		render json:resp
	end


	def create_invoice
		invoice_devices_params=params['invoice_devices']
	    invoice=Invoice.new({retail_company_branch_id:params[:branch_id]}) 
		invoice_devices=Array.new

	    invoice_devices_params.each do |item_param|
	    	invoice_devices << InvoiceDevice.new({device_id:item_param["device_id"],price:item_param["price"],quantity:item_param["quantity"]})
	        
	    end
	    invoice.invoice_devices=invoice_devices

	    if invoice.save
	      render json: invoice, status: :created
	    else
	        render json: invoice.errors, status: :unprocessable_entity
	    end  
	end
end
