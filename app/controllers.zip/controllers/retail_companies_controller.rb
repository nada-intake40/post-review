class RetailCompaniesController < ApplicationController
  before_action :authenticate_user!
  before_action :set_retail_company, only: [:show, :update, :destroy]

  # GET /retail_companies
  def index
    @retail_companies = RetailCompany.where(project_id: current_user.project_id)

    render json: @retail_companies
  end


  # GET /retail_companies/1
  def show
    render json: @retail_company
  end

  # POST /retail_companies
  def create
    retail=RetailCompany.find_by(project_id:current_user.project_id,retail_company_name:params[:retail_company_name])
    if(retail)
      render json: {error:"Name Already Taken"}, status: :unprocessable_entity
      return
    end
    

    @retail_company = RetailCompany.new(retail_company_params)
    @retail_company.project_id=current_user.project_id

    if @retail_company.save
      render json: @retail_company, status: :created, location: @retail_company
    else
      render json: @retail_company.errors, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /retail_companies/1
  def update
    if @retail_company.update(retail_company_params)
      render json: @retail_company
    else
      render json: @retail_company.errors, status: :unprocessable_entity
    end
  end

  # DELETE /retail_companies/1
  def destroy
    @retail_company.destroy
  end

  def get_branches_in_retails
    render json: RetailCompanyBranch.where(retail_company_id: params[:retail_id])
  end


  private
    # Use callbacks to share common setup or constraints between actions.
    def set_retail_company
      @retail_company = RetailCompany.find(params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def retail_company_params
      params.require(:retail_company).permit(:retail_company_name)
    end
end
