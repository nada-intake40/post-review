class CustomerServiceController < ApplicationController
  before_action :authenticate_user!
  require "base64"
  include PromoterHelper

  def add_sample
  	date = params[:date]
  	store_id = params[:store_id]
  	promoter_id = params[:promoter_id]
  	jcp = PromoterBranchDay.find_by(jcp_date: date , retail_company_branch_id: store_id , promoter_id: promoter_id)
  	if jcp
  		sample = Sample.find_by(promoter_branch_day_id: jcp.id)
  		if sample
  			sample.total_samples = params[:total_samples]
  			sample.distributed_samples = params[:distributed_samples]
  			sample.save
  		else
  		sample = Sample.create(promoter_branch_day_id: jcp.id , total_samples: params[:total_samples] , 
  			distributed_samples: params[:distributed_samples])
  		render json: sample
  	    end
  	else
	  	render json: {'error': 'invalid data'} , status: 422
	end
  end

  def add_customer_engagement
  	date = params[:date]
  	store_id = params[:store_id]
  	promoter_id = params[:promoter_id]
  	jcp = PromoterBranchDay.find_by(jcp_date: date , retail_company_branch_id: store_id , promoter_id: promoter_id)
  	if jcp
  		customer_engagement = CustomerEngagement.create(promoter_branch_day_id: jcp.id , customer_name: params[:customer_name] , 
  			phone: params[:phone] , email: params[:email])
  		render json: customer_engagement
  	else
	  	render json: {'error': 'invalid data'} , status: 422
	end
  end

  def submit_items_availabilities
  	params[:items].each do |item|
  		items = ItemsAvailability.create(item_id: item['item_id'],is_available: item['is_available'],promoter_branch_day_id: params[:jcp_id])
  	end
  end

  def get_high_periority_items
  	items = Item.joins(:brand,:category).where(brands:{project_id: current_user.project_id},periority: 1)
  	.select(:id , :item_name , "categories.category_name , brands.brand_name ,1 as is_available",:item_image)
  	render json: items
  end

  def delete_assigned_power_wing
  	PowerWing.where(id: params[:id]).destroy_all
  end

  def get_power_wings
  	jcp_date = PromoterBranchDay.find(params[:jcp_id]).jcp_date
  	power_wings = PowerOfWingsPhoto.joins(power_wing: :power_wings_type).where(promoter_branch_day_id: params[:jcp_id])
  	.select(:image,:is_found , :reason , ' power_wings.to_date , power_wings.from_date,power_wings_types.power_wing_type,
  		power_of_wings_photos.id, IF("'+jcp_date.to_s+'" < power_wings.to_date   , "n" , "y") as expiration ')
  	branch_id = PromoterBranchDay.find(params[:jcp_id]).retail_company_branch_id
  	power_wings_assigned_to_store = PowerWing.joins(:power_wings_type).where(retail_company_branch_id: branch_id)
  	.select(:to_date , :from_date,:id,'power_wings_types.power_wing_type')
  	render  json: {'power_wings_photos': power_wings , 'power_wings_assigned_to_store': power_wings_assigned_to_store}
  end

  def edit_check_in_out
  	unless params[:check_in_time].blank?
  		PromoterCheckIn.where(promoter_branch_day_id: params[:jcp_id]).update(created_at: params[:check_in_time])
  	end
  	unless params[:check_out_time].blank? 
  		PromoterCheckIn.where(promoter_branch_day_id: params[:jcp_id]).update(check_out_time: params[:check_out_time])
  	end
  	render json: 1

  end


  def edit_msl_item
  	item_availability = ItemsAvailability.find(params[:item_availability_id])
  	item_availability.is_available = params[:is_available]
  	item_availability.save
  	render json: item_availability
  end


  def add_jcp_implementation
  	jcp_implementation = JcpImplementation.where(promoter_branch_day_id: params[:jcp_id],category_id: params[:category_id])
  	unless jcp_implementation.blank?
  		jcp_implementation.destroy_all
  	end 
  	jcp_implementation = JcpImplementation.new({category_id: params[:category_id] , implementation_percentage: params[:implementation_percentage],
  		reason_id: params[:reason_id] , share_of_shelve_percentage: params[:share_of_shelve_percentage],
  		promoter_branch_day_id: params[:jcp_id]})
  	if jcp_implementation.save
  		if params[:planogram_before_images] != []
           upload_before_images(params[:jcp_id],params[:category_id],jcp_implementation.id,params[:planogram_before_images])   
        end
        if params[:planogram_after_images] != []
           upload_after_images(params[:jcp_id],params[:category_id],jcp_implementation.id,params[:planogram_after_images])
        end
  		render json: jcp_implementation
  	else
  		render json: jcp_implementation.errors
  	end
  end

  def get_reasons
  	render json: Reason.all
  end



	private

	def upload_before_images(jcp_id,category_id,jcp_implementation_id , images_array)
	              planogram_before_images = images_array
	              planogram_before_images.each do |image|
	               	  img_split = image.split(',')
                      ext_split = img_split[0].split('/')
                      ext = ext_split[1].split(";")
	                  before_image_path = get_planogram_before_image_dir(jcp_id,category_id)                      
                      image_string = img_split[1]
	                  before_image_path = get_planogram_before_image_dir(jcp_id,category_id)
	                  PlanogramBeforeImage.create({
	                  jcp_implementation_id: jcp_implementation_id,
	                  image_before:before_image_path,
	                })
	                save_planogram_before_images(image_string,before_image_path)
	              end
	end

	def upload_after_images(jcp_id,category_id,jcp_implementation_id , images_array)
	              planogram_after_images = images_array
	              planogram_after_images.each do |image|
	              	  img_split = image.split(',')
                      ext_split = img_split[0].split('/')
                      ext = ext_split[1].split(";")
	                  after_image_path = get_planogram_after_image_dir(jcp_id,category_id)
                      
                      image_string = img_split[1]
	                  PlanogramAfterImage.create({
	                  jcp_implementation_id: jcp_implementation_id,
	                  image_after:after_image_path,
	                })
	                save_planogram_after_images(image_string,after_image_path)
	              end
	end

	def save_planogram_before_images(image_string,image_path)
      File.open("public/#{image_path}", 'wb') do |f|
        f.write(Base64.decode64(image_string))
      end
    end

    def save_planogram_after_images(image_string,image_path)
      File.open("public/#{image_path}", 'wb') do |f|
        f.write(Base64.decode64(image_string))
      end
    end






end
