class AdminsController < ApplicationController
	before_action :authenticate_user!

	def list_projects
		render json: Project.all,:methods => [:formatted_end_date,:promoters_count,:days_left_percentage,:client_name]
	end

	def project_details
		render json: Project.joins(:users).select("projects.*,users.name,users.email").find(params[:project_id]),
			:methods => [:formatted_start_shift_from,:promoters_count,:days_left_percentage,:client_name,:project_accounts]
	end

	def add_project
		client=User.new(:email => params[:email], :password => params[:password], 
			:password_confirmation => params[:password],
			:name => params[:name],:user_role_id => '3' )
		if ! client.save
			render json:client.errors, status: :unprocessable_entity
			return
		end
		imageobj=manibulate_base64(params[:image_base64])
		
		path=generate_project_image_path( client.id ,imageobj["extension"] )
		save_profile_image(imageobj["image_string"],path)
		project=Project.new(start_date:params[:start_date],end_date:params[:end_date],
			project_name:params[:project_name],start_shift_from:params[:start_shift_from],
			shift_end_in:params[:shift_end_in],image_path: path,reset_time:params[:reset_time])

		if ! project.save
			render json:project.errors, status: :unprocessable_entity
			return
		end

		client.project_id=project.id
		client.save
		if project.save
			render json: project, status: :created
		else
			render json:project.errors, status: :unprocessable_entity

		end
	end

	def edit_project
		project=Project.find(params[:project_id])
		client=User.find_by_project_id(params[:project_id])
		imageobj=manibulate_base64(params[:image_base64])
		path=generate_project_image_path( client.id,imageobj["extension"] )
		save_profile_image(imageobj["image_string"],path)

		project.update(start_date:params[:start_date],end_date:params[:end_date],
			project_name:params[:project_name],start_shift_from:params[:start_shift_from],
			shift_end_in:params[:shift_end_in],	image_path: path,reset_time:params[:reset_time] )
		client.update(:email => params[:email], :password => params[:password], 
			:password_confirmation => params[:password],
			:name => [:name],:user_role_id => '3')
		if project.save && client.save
			render json: project, status: :created
		else
			render json:{client_errors:client.errors,project_errors:project.errors}, status: :unprocessable_entity

		end
	end

	def delete_project
		project=Project.find(params[:project_id])
		project.destroy

		render json:{}

	end

	def submit_reports_access_to_user
		client=User.find(params[:client_id])
		old_access=UsersAccessReport.where(user_id:client.id)
		if (old_access.count > 0)
			old_access.destroy_all
		end

		params[:report_keys].map { |key|
			key=ReportsAccessKey.find_by_access_key(key)
			UsersAccessReport.create(user_id:client.id,reports_access_key_id:key.id)
		}
		render json:{msg:"success"}
	end

	private

	def generate_project_image_path(client_id,extension)
		path="clients/#{client_id}/profile.#{extension}"
	    dir = File.dirname("public/#{path}")
	    FileUtils.mkdir_p(dir) unless File.directory?(dir)

	    path

	end

	def save_profile_image(image_string,image_path)
		File.open("public/#{image_path}", 'wb') do |f|
        f.write(Base64.decode64(image_string))
      end
	end

	def manibulate_base64(string)
		image_string_obj={}
		image_string_obj["image_string"]=string.split(',')[1]
		image_string_obj["extension"]=string.split(',')[0].split('data:image/')[1].split(';')[0]
		image_string_obj
	end

	def login_to_client_dashboard(project_id)
		new_email=client_user.email+"_tmp"
		new_password="12345678"
		client_user=User.find_by_email(new_email)
		if client_user
			client_user.delete
		end
		client_user=current_user.dub
		client_user.email=new_email
		client_user.password=new_password
		client_user.project_id=project_id
		client_user.user_role_id=3

		if client_user.save 
			render json: client_user
		else
			render json: client_user.errors

		end
	end


end