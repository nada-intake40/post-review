class PowerWingController < ApplicationController
  before_action :authenticate_user!
  include PromoterHelper

  def get_power_wings_numbers
  	project_id = current_user.project_id
  	stands_number = PowerWingsType.where(project_id: project_id).count
  	stores_number = RetailCompanyBranch.joins(:city).where(cities: {project_id: project_id}).count
  	stores_with_power_wings = PowerWing.joins(:power_wings_type).where(power_wings_types:{project_id:project_id}).count
  	render json: {'power_wings_count': stands_number , 'stores_count': stores_number ,
  		'stores_with_power_wings': stores_with_power_wings}
  end

  def delete_power_wing_photo
  	PowerOfWingsPhoto.find(params[:power_wing_photo_id]).destroy
  end

  def delete_assigned_power_wing
  	PowerWing.find(params[:power_wing_id]).destroy
  end

  def list_of_stand_tracking
  	stand_id = params[:stand_id]
  	stand = PowerWing.joins(:power_wings_type , retail_company_branch: [:retail_company , :city])
  	.where(id: stand_id).select("power_wings_types.power_wing_type" , :from_date , 
  		:to_date ,'retail_company_branches.branch_name , retail_companies.retail_company_name , 
  		cities.city_name , power_wings.id , IF("'+Date.today.to_s+'" < power_wings.to_date   , "n" , "y") as expiration')
  	power_wings_photos = PowerOfWingsPhoto.joins(:power_wing , promoter_branch_day: :promoter).where(power_wing_id:stand_id).select(
  		:image,:is_found , :reason , 'promoters.id as promoter_id, promoter_branch_days.jcp_date , promoters.username ,
  		promoters.image as promoter_image , IF("'+Date.today.to_s+'" < power_wings.to_date   , "n" , "y") as expiration ,
  		power_of_wings_photos.id')

 	render json: {power_wing: stand[0] ,power_wings_photos: power_wings_photos}
  end

  def list_of_assigned_power_wings
  	  project_id = current_user.project_id
      city_id = params[:city_id].blank? ? City.where(project_id: project_id).pluck(:id) : params[:city_id]
      retail_id = params[:retail_id].blank? ? RetailCompany.where(project_id: project_id).pluck(:id) : params[:retail_id]
      branch_id = params[:branch_id].blank? ? RetailCompanyBranch.joins(:retail_company)
      .where(retail_companies: {project_id: project_id}).pluck(:id) : params[:branch_id]
      start_date = params[:start_date].blank? ? Date.today-30 : Date.parse(params[:start_date])
      end_date = params[:end_date].blank? ? Date.today : Date.parse(params[:end_date])

   	  render json: PowerWing.joins(:power_wings_type ,retail_company_branch: [:retail_company , :city]).where(retail_company_branches:{
  		retail_company_id: retail_id, city_id: city_id} , retail_company_branch_id:
  		branch_id ,power_wings_types: {project_id: current_user.project_id}).where('(power_wings.from_date >= "'+start_date.to_s+'" AND power_wings.from_date <= "'+end_date.to_s+'") OR 
  		(power_wings.to_date >= "'+start_date.to_s+'" AND power_wings.to_date <= "'+end_date.to_s+'") OR 
  		("'+start_date.to_s+'" >= power_wings.from_date AND "'+start_date.to_s+'" <= power_wings.to_date) OR
  		("'+end_date.to_s+'" >= power_wings.from_date AND "'+end_date.to_s+'" <= power_wings.to_date)')
   	  .select('power_wings_types.power_wing_type , power_wings_types.image ,
  		retail_company_branches.branch_name  , retail_companies.retail_company_name , 
  		cities.city_name , power_wings.id ,power_wings.from_date , power_wings.to_date
  		, IF("'+Date.today.to_s+'" < power_wings.to_date   , "n" , "y") as expiration')
  end

  def assign_power_wings_to_store
  	power_wing = PowerWing.create(power_wings_type_id:params[:power_wings_type_id],
  		retail_company_branch_id:params[:retail_company_branch_id],from_date:params[:from],
  		to_date:params[:to])
  	render json: power_wing
  end

  def edit_power_wing_type
  	power_wing_type = PowerWingsType.find(params[:power_wing_type_id])
  	power_wing_type.power_wing_type = params[:type]
  	if(params[:image] != "")
            image = params[:image]
            img_split = image.split(',')
            ext_split = img_split[0].split('/')
            ext = ext_split[1].split(";")
            image_path = get_power_of_wings_type_photo_dir(power_wing_type.id,ext[0])
            image_string = img_split[1]
            save_power_of_wings_types_image(image_string,image_path)
            power_wing_type.image = image_path
      end
      if power_wing_type.save
	      render json: power_wing_type
	  else
	  	render json: power_wing_type.errors , status: 422
	  end
  end


  def delete_power_wing_type
  	PowerWingsType.find(params[:power_wing_type_id]).destroy
  end 

  def get_list_of_power_wings_types
  	project_id = current_user.project_id
    render json: PowerWingsType.where(project_id: project_id)
  end

  def create_power_wings_type
  	project_id = current_user.project_id
    power_wing_type = PowerWingsType.new({power_wing_type: params[:type] , project_id: project_id})
    power_wing_type.save
    if(params[:image] != "")
            image = params[:image]
            img_split = image.split(',')
            ext_split = img_split[0].split('/')
            ext = ext_split[1].split(";")
            image_path = get_power_of_wings_type_photo_dir(power_wing_type.id,ext[0])
            image_string = img_split[1]
            save_power_of_wings_types_image(image_string,image_path)
            power_wing_type.image = image_path
      end
      if power_wing_type.save
          render json: power_wing_type
      else
        render json: power_wing_type.errors , status: 422
      end
  end


  private 

  def save_power_of_wings_types_image(image_string,image_path)
      File.open("public/#{image_path}", 'wb') do |f|
        f.write(Base64.decode64(image_string))
      end
    end


end
